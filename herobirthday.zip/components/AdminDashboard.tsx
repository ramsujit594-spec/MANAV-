
import React, { useState, useEffect } from 'react';
import { Wish } from '../types';
import * as XLSX from 'xlsx';
import { saveFirebaseConfig, getFirebaseConfig, clearFirebaseConfig } from '../services/firebaseConfig';
import { migrateLocalToCloud, uploadBackupToCloud, isCloudStorageActive } from '../services/wishService';

interface AdminDashboardProps {
  wishes: Wish[];
  visitorCount: number;
  cloudMode: boolean;
  setCloudMode: (enabled: boolean) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ wishes, visitorCount, cloudMode, setCloudMode }) => {
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [showSyncConfirm, setShowSyncConfirm] = useState(false);
  const [copyFeedback, setCopyFeedback] = useState('');
  const [exportStatus, setExportStatus] = useState<'idle' | 'exporting' | 'uploading' | 'done'>('idle');
  const [isToggling, setIsToggling] = useState(false);
  const [hasCustomConfig, setHasCustomConfig] = useState(false);
  const [syncOnSwitch, setSyncOnSwitch] = useState(true);
  const [isSavingConfig, setIsSavingConfig] = useState(false);
  
  // Backup Mode: 'local' (Download to device) or 'cloud' (Upload to storage + Email link)
  const [backupMode, setBackupMode] = useState<'local' | 'cloud'>('local');

  // Config Form State
  const [configForm, setConfigForm] = useState({
    apiKey: '',
    authDomain: '',
    projectId: '',
    storageBucket: '',
    messagingSenderId: '',
    appId: '',
    measurementId: '',
    adminEmail: ''
  });

  useEffect(() => {
    const currentConfig = getFirebaseConfig();
    if (currentConfig) {
      setHasCustomConfig(true);
      // Ensure we don't crash if old config didn't have adminEmail or measurementId
      setConfigForm({ 
          apiKey: '',
          authDomain: '',
          projectId: '',
          storageBucket: '',
          messagingSenderId: '',
          appId: '',
          measurementId: '',
          adminEmail: '',
          ...currentConfig 
      });
      
      // Default to cloud backup if custom config is present
      if (isCloudStorageActive()) {
        setBackupMode('cloud');
      }
    }
  }, []);

  const totalWishes = wishes.length;
  
  // Calculate today's wishes
  const today = new Date().toDateString();
  const todaysWishes = wishes.filter(w => new Date(w.timestamp).toDateString() === today).length;

  // Extract unique emails
  const uniqueEmails = [...new Set(
    wishes
      .map(w => w.email)
      .filter((email): email is string => !!email && email.trim() !== '')
  )];
  const totalEmails = uniqueEmails.length;

  const handleBulkReply = () => {
    // We use BCC to protect user privacy so they don't see each other's emails
    const mailtoLink = `mailto:?bcc=${uniqueEmails.join(',')}&subject=Update from HeroBirthday Bash!`;
    window.location.href = mailtoLink;
  };

  const handleCopyEmails = () => {
    const emailString = uniqueEmails.join(', ');
    navigator.clipboard.writeText(emailString).then(() => {
      setCopyFeedback('Copied!');
      setTimeout(() => setCopyFeedback(''), 2000);
    });
  };

  const handleBackupModeToggle = () => {
      if (backupMode === 'local') {
          // We are trying to switch TO cloud
          if (!isCloudStorageActive()) {
              alert("Secure Cloud Vault requires a valid Cloud Configuration.\nPlease connect your project first.");
              setShowConfigModal(true);
              return;
          }
          setBackupMode('cloud');
      } else {
          setBackupMode('local');
      }
  };

  const handleSyncToggleRequest = () => {
      // If we are about to switch TO Cloud, check if user wants to sync
      if (!cloudMode) {
          setSyncOnSwitch(true); // Default to true
      }
      setShowSyncConfirm(true);
  };

  const executeSyncToggle = async () => {
      setShowSyncConfirm(false);
      
      // Auto-Sync Logic: If switching TO Cloud and Sync is requested
      if (!cloudMode && syncOnSwitch) {
          setIsToggling(true);
          try {
              // Perform Backup based on selected mode
              const excelUrl = await performExportExcel(backupMode === 'cloud');
              const sqlUrl = await performExportSQL(backupMode === 'cloud');
              
              if (backupMode === 'cloud' && (excelUrl || sqlUrl)) {
                   openEmailWithBackups(excelUrl, sqlUrl);
              }

              // Migrate Local Data to Cloud
              await migrateLocalToCloud();
              
          } catch (e) {
              console.error("Auto-sync error:", e);
              alert("Auto-sync experienced an issue, but mode will still switch.");
          }
      }

      setIsToggling(true);
      setTimeout(() => {
          setCloudMode(!cloudMode);
          setIsToggling(false);
      }, 800);
  };

  const handleConfigSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Safety Validation
    if (!configForm.apiKey || !configForm.projectId) {
        alert("Please enter at least the API Key and Project ID.");
        return;
    }

    setIsSavingConfig(true);
    // Short delay to show the loading state
    await new Promise(resolve => setTimeout(resolve, 800));
    saveFirebaseConfig(configForm);
  };

  const handleClearConfig = () => {
    if (confirm("Disconnect from this Cloud Project? The app will revert to Local Storage.")) {
      clearFirebaseConfig();
    }
  };

  const openEmailWithBackups = (excelUrl?: string, sqlUrl?: string) => {
      const recipient = configForm.adminEmail || ""; 
      const subject = encodeURIComponent("HeroBirthday: Secure Cloud Backups & Sync Report");
      let body = encodeURIComponent(`Secure Data Transfer Report\n\nTo: Admin (${recipient || 'Self'})\nFrom: HeroBirthday Data Center\n\n`);
      
      if (excelUrl) body += encodeURIComponent(`[SECURE EXCEL BACKUP]: ${excelUrl}\n\n`);
      if (sqlUrl) body += encodeURIComponent(`[SECURE SQL DUMP]: ${sqlUrl}\n\n`);
      
      body += encodeURIComponent("Files are encrypted and stored in your private Cloud Storage bucket.\nLocal copies have been purged for safety.");
      
      window.location.href = `mailto:${recipient}?subject=${subject}&body=${body}`;
  };

  // --- Excel Export Functionality ---
  
  const generateExcelBlob = (): Blob => {
    const dataToExport = wishes.map(w => ({
      ID: w.id,
      Name: w.name,
      Email: w.email || 'N/A',
      Message: w.message,
      Date: new Date(w.timestamp).toLocaleDateString(),
      Time: new Date(w.timestamp).toLocaleTimeString(),
      Hero: w.character,
      Theme: w.theme || w.character,
      'AI Response': w.aiResponse || 'Pending',
      'Admin Reply': w.adminReply || ''
    }));

    const wb = XLSX.utils.book_new();
    const ws = XLSX.utils.json_to_sheet(dataToExport);
    const wscols = [
      { wch: 10 }, { wch: 20 }, { wch: 25 }, { wch: 50 }, { wch: 12 }, { wch: 10 }, { wch: 15 },
    ];
    ws['!cols'] = wscols;
    XLSX.utils.book_append_sheet(wb, ws, "Wishes_Data");
    
    // Write to ArrayBuffer then Blob
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    return new Blob([wbout], { type: 'application/octet-stream' });
  };

  const performExportExcel = async (uploadToCloud: boolean): Promise<string | undefined> => {
      setExportStatus(uploadToCloud ? 'uploading' : 'exporting');
      
      try {
          const blob = generateExcelBlob();
          const fileName = `HeroBirthday_Data_${new Date().toISOString().slice(0,10)}.xlsx`;

          if (uploadToCloud) {
              if (!isCloudStorageActive()) {
                   throw new Error("Cloud storage is not configured.");
              }
              const url = await uploadBackupToCloud(blob, fileName);
              if (!syncOnSwitch) openEmailWithBackups(url, undefined); // Open email if this was a manual click
              setExportStatus('done');
              setTimeout(() => setExportStatus('idle'), 2000);
              return url;
          } else {
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = fileName;
              document.body.appendChild(a);
              a.click();
              document.body.removeChild(a);
              URL.revokeObjectURL(url);
              setExportStatus('done');
              setTimeout(() => setExportStatus('idle'), 2000);
              return undefined;
          }
      } catch (error: any) {
          console.error("Excel export failed", error);
          if (error.message === "Cloud storage is not configured.") {
             alert("You must connect a Cloud Database to use the Secure Vault feature.");
             setShowConfigModal(true);
          } else {
             alert("Export failed. If uploading to cloud, check Storage permissions.");
          }
          setExportStatus('idle');
          return undefined;
      }
  };

  // --- SQL Export Functionality ---
  
  const generateSQLBlob = (): Blob => {
    let sqlContent = `-- HeroBirthday Database Dump (${cloudMode ? 'Cloud' : 'Local Storage'})\n`;
    sqlContent += `-- Generated: ${new Date().toISOString()}\n\n`;
    sqlContent += `CREATE TABLE IF NOT EXISTS wishes (\n`;
    sqlContent += `  id VARCHAR(255) PRIMARY KEY,\n`;
    sqlContent += `  name VARCHAR(255) NOT NULL,\n`;
    sqlContent += `  email VARCHAR(255),\n`;
    sqlContent += `  message TEXT,\n`;
    sqlContent += `  timestamp BIGINT,\n`;
    sqlContent += `  hero VARCHAR(50),\n`;
    sqlContent += `  ai_response TEXT,\n`;
    sqlContent += `  admin_reply TEXT\n`;
    sqlContent += `);\n\n`;

    if (wishes.length > 0) {
      sqlContent += `INSERT INTO wishes (id, name, email, message, timestamp, hero, ai_response, admin_reply) VALUES\n`;
      const rows = wishes.map((w) => {
        const sanitize = (str?: string) => str ? `'${str.replace(/'/g, "''").replace(/\n/g, "\\n")}'` : 'NULL';
        return `(${sanitize(w.id)}, ${sanitize(w.name)}, ${sanitize(w.email)}, ${sanitize(w.message)}, ${w.timestamp}, ${sanitize(w.character)}, ${sanitize(w.aiResponse)}, ${sanitize(w.adminReply)})`;
      });
      sqlContent += rows.join(',\n') + ';\n';
    }
    return new Blob([sqlContent], { type: 'text/sql' });
  };

  const performExportSQL = async (uploadToCloud: boolean): Promise<string | undefined> => {
    setExportStatus(uploadToCloud ? 'uploading' : 'exporting');

    try {
        const blob = generateSQLBlob();
        const fileName = `hero_birthday_dump_${new Date().toISOString().slice(0,10)}.sql`;

        if (uploadToCloud) {
            if (!isCloudStorageActive()) {
                 throw new Error("Cloud storage is not configured.");
            }
            const url = await uploadBackupToCloud(blob, fileName);
            if (!syncOnSwitch) openEmailWithBackups(undefined, url); // Open email if manual click
            setExportStatus('done');
            setTimeout(() => setExportStatus('idle'), 2000);
            return url;
        } else {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            setExportStatus('done');
            setTimeout(() => setExportStatus('idle'), 2000);
            return undefined;
        }
    } catch (error: any) {
        console.error("SQL export failed", error);
        if (error.message === "Cloud storage is not configured.") {
             alert("You must connect a Cloud Database to use the Secure Vault feature.");
             setShowConfigModal(true);
        } else {
             alert("Export failed. If uploading to cloud, check Storage permissions.");
        }
        setExportStatus('idle');
        return undefined;
    }
  };

  return (
    <div className="mt-12 animate-fade-in-up">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center border-b border-gray-800 pb-2 mb-6 gap-4">
          <h3 className="text-2xl font-bold text-gray-500 uppercase flex items-center gap-3">
            <i className="fas fa-chart-line text-spidey-blue"></i>
            Admin Dashboard
          </h3>
          
          <div className="flex items-center gap-3">
            {/* Configure Button */}
            <button
               onClick={() => setShowConfigModal(true)}
               className={`relative overflow-hidden group text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full border transition-all duration-300 ${hasCustomConfig ? 'border-green-500 text-green-500 bg-green-900/10 hover:bg-green-900/20' : 'border-gray-600 text-gray-400 hover:text-white hover:border-white'}`}
            >
               <span className="relative z-10 flex items-center">
                 <i className={`fas ${hasCustomConfig ? 'fa-link' : 'fa-plug'} mr-2 ${hasCustomConfig ? 'animate-pulse' : ''}`}></i>
                 {hasCustomConfig ? 'Cloud Connected' : 'Connect Cloud'}
               </span>
               <div className="absolute inset-0 bg-white/10 translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-700 skew-x-12"></div>
            </button>

            {/* Animated Sync Toggle */}
            <div className="flex items-center gap-4 bg-black/40 p-2 rounded-lg border border-gray-800">
               <span className={`text-xs font-bold uppercase tracking-wider ${!cloudMode ? 'text-white' : 'text-gray-600'}`}>Local</span>
               
               <button 
                  onClick={handleSyncToggleRequest}
                  className={`w-14 h-7 rounded-full relative transition-colors duration-300 focus:outline-none shadow-inner ${cloudMode ? 'bg-green-600' : 'bg-gray-700'}`}
                  title={`Toggle Sync: ${cloudMode ? 'Connected to Cloud' : 'Offline Mode'}`}
               >
                  <div 
                      className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-md transition-all duration-300 flex items-center justify-center ${cloudMode ? 'left-8' : 'left-1'}`}
                  >
                      {isToggling ? (
                          <i className="fas fa-circle-notch fa-spin text-[10px] text-black"></i>
                      ) : (
                          <i className={`fas ${cloudMode ? 'fa-cloud' : 'fa-hdd'} text-[10px] ${cloudMode ? 'text-green-600' : 'text-gray-700'}`}></i>
                      )}
                  </div>
               </button>
               
               <span className={`text-xs font-bold uppercase tracking-wider ${cloudMode ? 'text-green-500' : 'text-gray-600'}`}>Cloud Sync</span>
            </div>
          </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Total Wishes Card */}
        <div className="bg-dark p-6 rounded-lg border-2 border-spidey-blue/30 shadow-[0_0_15px_rgba(35,104,184,0.1)] flex flex-col items-center justify-center relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:border-spidey-blue hover:shadow-[0_0_30px_rgba(35,104,184,0.4)]">
          <div className="absolute inset-0 bg-gradient-to-br from-spidey-blue/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          <div className="absolute -right-10 -top-10 text-9xl text-spidey-blue/5 group-hover:text-spidey-blue/10 transition-colors duration-300 rotate-12">
            <i className="fas fa-scroll"></i>
          </div>
          
          <i className="fas fa-scroll text-4xl text-spidey-blue mb-2 relative z-10 group-hover:scale-110 transition-transform duration-300 drop-shadow-[0_0_10px_rgba(35,104,184,0.5)]"></i>
          <span className="text-5xl font-bold text-white mb-1 relative z-10 drop-shadow-md">{totalWishes}</span>
          <span className="text-sm font-bold text-gray-400 uppercase tracking-widest relative z-10 group-hover:text-spidey-blue transition-colors">Total Wishes</span>
        </div>

        {/* Today's Wishes Card */}
        <div className="bg-dark p-6 rounded-lg border-2 border-ghost-flame/30 shadow-[0_0_15px_rgba(255,69,0,0.1)] flex flex-col items-center justify-center relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:border-ghost-flame hover:shadow-[0_0_30px_rgba(255,69,0,0.4)]">
          <div className="absolute inset-0 bg-gradient-to-br from-ghost-flame/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
           <div className="absolute -right-10 -top-10 text-9xl text-ghost-flame/5 group-hover:text-ghost-flame/10 transition-colors duration-300 rotate-12">
            <i className="fas fa-calendar-day"></i>
          </div>

          <i className="fas fa-calendar-day text-4xl text-ghost-flame mb-2 relative z-10 group-hover:scale-110 transition-transform duration-300 drop-shadow-[0_0_10px_rgba(255,69,0,0.5)]"></i>
          <span className="text-5xl font-bold text-white mb-1 relative z-10 drop-shadow-md">{todaysWishes}</span>
          <span className="text-sm font-bold text-gray-400 uppercase tracking-widest relative z-10 group-hover:text-ghost-flame transition-colors">Today's Wishes</span>
        </div>

        {/* Visitors Card */}
        <div className="bg-dark p-6 rounded-lg border-2 border-green-500/30 shadow-[0_0_15px_rgba(34,197,94,0.1)] flex flex-col items-center justify-center relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:border-green-500 hover:shadow-[0_0_30px_rgba(34,197,94,0.4)]">
          <div className="absolute inset-0 bg-gradient-to-br from-green-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
           <div className="absolute -right-10 -top-10 text-9xl text-green-500/5 group-hover:text-green-500/10 transition-colors duration-300 rotate-12">
            <i className="fas fa-users"></i>
          </div>

          <i className="fas fa-users text-4xl text-green-500 mb-2 relative z-10 group-hover:scale-110 transition-transform duration-300 drop-shadow-[0_0_10px_rgba(34,197,94,0.5)]"></i>
          <span className="text-5xl font-bold text-white mb-1 relative z-10 drop-shadow-md">{visitorCount}</span>
          <span className="text-sm font-bold text-gray-400 uppercase tracking-widest relative z-10 group-hover:text-green-500 transition-colors">Total Visitors</span>
        </div>

        {/* Email Bank Card */}
        <div 
            onClick={() => setShowEmailModal(true)}
            className="bg-dark p-6 rounded-lg border-2 border-yellow-500/30 shadow-[0_0_15px_rgba(234,179,8,0.1)] flex flex-col items-center justify-center relative overflow-hidden group transition-all duration-300 hover:scale-105 hover:border-yellow-500 hover:shadow-[0_0_30px_rgba(234,179,8,0.4)] cursor-pointer"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
           <div className="absolute -right-10 -top-10 text-9xl text-yellow-500/5 group-hover:text-yellow-500/10 transition-colors duration-300 rotate-12">
            <i className="fas fa-envelope-open-text"></i>
          </div>

          <i className="fas fa-envelope-open-text text-4xl text-yellow-500 mb-2 relative z-10 group-hover:scale-110 transition-transform duration-300 drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]"></i>
          <span className="text-5xl font-bold text-white mb-1 relative z-10 drop-shadow-md">{totalEmails}</span>
          <span className="text-sm font-bold text-gray-400 uppercase tracking-widest relative z-10 group-hover:text-yellow-500 transition-colors flex items-center gap-2">
             User Emails <i className="fas fa-external-link-alt text-xs"></i>
          </span>
        </div>
      </div>

      {/* Data Management Section (Excel & SQL) */}
      <div className="mt-8 bg-dark p-6 rounded-lg border border-gray-800 shadow-hero relative overflow-hidden group hover:border-blue-500/50 hover:shadow-[0_0_20px_rgba(35,104,184,0.2)] transition-all duration-500">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-900/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        {/* Connection Status Ribbon */}
        {cloudMode && hasCustomConfig && (
            <div className="absolute top-0 right-0 bg-green-600 text-white text-[10px] font-bold uppercase tracking-widest px-3 py-1 rounded-bl-lg shadow-lg z-10">
                <i className="fas fa-bolt mr-1"></i> Instant Sync Active (0.05s)
            </div>
        )}

        <div className="flex justify-between items-center mb-4 relative z-10 flex-wrap gap-4">
             <h4 className="text-lg font-bold text-light uppercase flex items-center gap-2">
                <i className="fas fa-database text-blue-400 animate-pulse"></i> Data Center
            </h4>
            
            <div className="flex items-center gap-3">
                 {/* Email Config Button */}
                 <button 
                    onClick={() => setShowConfigModal(true)}
                    className={`h-8 px-3 rounded-full border flex items-center gap-2 transition-all duration-300 transform hover:scale-105 ${configForm.adminEmail ? 'bg-green-900/20 border-green-500/50 text-green-500 hover:bg-green-900/40' : 'bg-black/40 border-gray-700 text-gray-400 hover:border-gray-500 hover:text-gray-200'}`}
                    title="Configure Backup Email"
                 >
                    <i className={`fas fa-envelope ${!configForm.adminEmail ? 'animate-bounce' : ''}`}></i>
                    <span className="text-[10px] font-bold uppercase tracking-widest hidden sm:inline">
                        {configForm.adminEmail ? 'Email Set' : 'Add Email'}
                    </span>
                 </button>

                {/* Secure Vault Switch */}
                <div className="flex items-center gap-3 bg-black/40 px-3 py-1.5 rounded-full border border-gray-700 hover:border-purple-500/50 transition-all duration-300 group/switch">
                    <span className={`text-[10px] font-bold uppercase tracking-widest transition-colors ${backupMode === 'local' ? 'text-white' : 'text-gray-500'}`}>Device</span>
                    <button 
                       onClick={handleBackupModeToggle}
                       className={`w-10 h-5 rounded-full relative transition-all duration-300 focus:outline-none shadow-inner ${backupMode === 'cloud' ? 'bg-purple-600 shadow-[0_0_10px_rgba(147,51,234,0.5)]' : 'bg-gray-600'}`}
                    >
                        <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-md transition-all duration-300 ${backupMode === 'cloud' ? 'left-6' : 'left-1'}`}></div>
                    </button>
                    <span className={`text-[10px] font-bold uppercase tracking-widest flex items-center gap-1 transition-colors ${backupMode === 'cloud' ? 'text-purple-400' : 'text-gray-500'}`}>
                        {backupMode === 'cloud' && <i className="fas fa-lock text-[10px] animate-pulse"></i>}
                        Cloud
                    </span>
                </div>
            </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 relative z-10">
            <button
                onClick={() => performExportExcel(backupMode === 'cloud')}
                className={`p-4 rounded-lg flex items-center justify-between group/btn transition-colors border ${backupMode === 'cloud' ? 'bg-purple-900/30 border-purple-500/30 hover:bg-purple-900/50 hover:shadow-[0_0_15px_rgba(168,85,247,0.3)]' : 'bg-green-700 hover:bg-green-600 border-green-600/30 hover:shadow-[0_0_15px_rgba(34,197,94,0.3)]'} text-white`}
                disabled={exportStatus !== 'idle'}
            >
                <div className="flex items-center gap-3">
                    <i className={`fas ${backupMode === 'cloud' ? 'fa-cloud-upload-alt' : 'fa-file-excel'} text-2xl group-hover/btn:scale-110 transition-transform duration-300`}></i>
                    <div className="text-left">
                        <div className="font-bold uppercase tracking-wider">{backupMode === 'cloud' ? 'Secure Excel Backup' : 'Export to Excel'}</div>
                        <div className={`text-xs ${backupMode === 'cloud' ? 'text-purple-200' : 'text-green-200'}`}>
                            {backupMode === 'cloud' ? 'Email Safe Link' : 'Save .xlsx to Device'}
                        </div>
                    </div>
                </div>
                <i className={`fas ${backupMode === 'cloud' ? 'fa-lock' : 'fa-download'} opacity-50 group-hover/btn:opacity-100 transition-opacity`}></i>
            </button>

            <button
                onClick={() => performExportSQL(backupMode === 'cloud')}
                className={`p-4 rounded-lg flex items-center justify-between group/btn transition-colors border ${backupMode === 'cloud' ? 'bg-purple-900/30 border-purple-500/30 hover:bg-purple-900/50 hover:shadow-[0_0_15px_rgba(168,85,247,0.3)]' : 'bg-blue-800 hover:bg-blue-700 border-blue-600/30 hover:shadow-[0_0_15px_rgba(35,104,184,0.3)]'} text-white`}
                disabled={exportStatus !== 'idle'}
            >
                <div className="flex items-center gap-3">
                    <i className={`fas ${backupMode === 'cloud' ? 'fa-server' : 'fa-database'} text-2xl group-hover/btn:scale-110 transition-transform duration-300`}></i>
                    <div className="text-left">
                        <div className="font-bold uppercase tracking-wider">{backupMode === 'cloud' ? 'Secure SQL Dump' : 'Backup to SQL'}</div>
                        <div className={`text-xs ${backupMode === 'cloud' ? 'text-purple-200' : 'text-blue-200'}`}>
                            {backupMode === 'cloud' ? 'Email Safe Link' : 'Save .sql to Device'}
                        </div>
                    </div>
                </div>
                <i className={`fas ${backupMode === 'cloud' ? 'fa-lock' : 'fa-download'} opacity-50 group-hover/btn:opacity-100 transition-opacity`}></i>
            </button>
        </div>
        
        {exportStatus === 'uploading' && (
            <p className="text-purple-400 text-xs mt-3 text-center animate-pulse font-bold uppercase tracking-widest relative z-10">
                <i className="fas fa-circle-notch fa-spin mr-2"></i> Encrypting & Uploading to Vault...
            </p>
        )}
        {exportStatus === 'done' && (
            <p className="text-green-500 text-xs mt-3 text-center animate-pulse font-bold uppercase tracking-widest relative z-10">
                <i className="fas fa-check-circle mr-2"></i> {backupMode === 'cloud' ? 'Secure Link Generated!' : 'Export Complete'}
            </p>
        )}
      </div>

      {/* Cloud Configuration Modal */}
      {showConfigModal && (
        <div className="fixed inset-0 bg-black/95 z-[95] flex items-center justify-center p-4 animate-[fadeIn_0.1s_ease-out]">
            <div className="bg-ghost-black border-[3px] border-green-600 w-full max-w-2xl rounded-lg shadow-[0_0_30px_rgba(34,197,94,0.2)] flex flex-col max-h-[90vh] animate-[zoomIn_0.1s_ease-out]">
                 <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-ghost-black rounded-t-lg">
                    <h4 className="text-xl font-bold text-green-500 uppercase flex items-center gap-2">
                        <i className="fas fa-cloud-upload-alt"></i> Connect Real Cloud
                    </h4>
                    <button 
                        onClick={() => setShowConfigModal(false)}
                        className="text-gray-400 hover:text-white p-2"
                    >
                        <i className="fas fa-times text-xl"></i>
                    </button>
                </div>
                
                <div className="p-6 overflow-y-auto custom-scrollbar">
                    <p className="text-gray-300 mb-4 text-sm">
                        To enable real-time sync (0.05s latency) and permanent storage, paste your Firebase Configuration below. 
                        Data will be stored in your own secure cloud database.
                    </p>
                    
                    <form onSubmit={handleConfigSubmit} className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">API Key</label>
                                <input 
                                    type="text" 
                                    value={configForm.apiKey}
                                    onChange={(e) => setConfigForm({...configForm, apiKey: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="AIzaSy..."
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">Auth Domain</label>
                                <input 
                                    type="text" 
                                    value={configForm.authDomain}
                                    onChange={(e) => setConfigForm({...configForm, authDomain: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="project-id.firebaseapp.com"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">Project ID</label>
                                <input 
                                    type="text" 
                                    value={configForm.projectId}
                                    onChange={(e) => setConfigForm({...configForm, projectId: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="project-id"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">Storage Bucket</label>
                                <input 
                                    type="text" 
                                    value={configForm.storageBucket}
                                    onChange={(e) => setConfigForm({...configForm, storageBucket: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="project-id.appspot.com"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">Messaging Sender ID</label>
                                <input 
                                    type="text" 
                                    value={configForm.messagingSenderId}
                                    onChange={(e) => setConfigForm({...configForm, messagingSenderId: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="123456789"
                                    required
                                />
                            </div>
                            <div>
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">App ID</label>
                                <input 
                                    type="text" 
                                    value={configForm.appId}
                                    onChange={(e) => setConfigForm({...configForm, appId: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="1:123456789:web:abcdef..."
                                    required
                                />
                            </div>
                            <div className="md:col-span-2">
                                <label className="block text-gray-500 text-xs font-bold uppercase mb-1">Measurement ID (GA4)</label>
                                <input 
                                    type="text" 
                                    value={configForm.measurementId}
                                    onChange={(e) => setConfigForm({...configForm, measurementId: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="G-XXXXXXXXXX"
                                />
                                <p className="text-[10px] text-gray-500 mt-1">
                                    Optional: Add Google Analytics Measurement ID for real-time user tracking.
                                </p>
                            </div>

                            <div className="md:col-span-2 border-t border-gray-800 pt-4 mt-2">
                                <label className="block text-green-500 text-xs font-bold uppercase mb-1">
                                    <i className="fas fa-envelope mr-1"></i> Admin Email for Safe Backups
                                </label>
                                <input 
                                    type="email" 
                                    value={configForm.adminEmail}
                                    onChange={(e) => setConfigForm({...configForm, adminEmail: e.target.value})}
                                    className="w-full bg-dark border border-gray-700 rounded p-2 text-light text-sm focus:border-green-500 focus:outline-none"
                                    placeholder="admin@example.com (Backups will be sent here)"
                                />
                                <p className="text-[10px] text-gray-500 mt-1">
                                    Required for the "Secure Cloud Vault" feature to automatically address backup emails to you.
                                </p>
                            </div>
                        </div>

                        <div className="flex gap-3 pt-4 border-t border-gray-800">
                             {hasCustomConfig && (
                                <button 
                                    type="button"
                                    onClick={handleClearConfig}
                                    className="px-4 py-2 bg-red-900/30 text-red-500 border border-red-900 rounded hover:bg-red-900/50 transition-colors uppercase font-bold text-xs tracking-wider"
                                >
                                    Disconnect
                                </button>
                             )}
                             <button 
                                type="submit"
                                disabled={isSavingConfig}
                                className="flex-1 bg-green-600 hover:bg-green-500 text-white py-3 rounded uppercase font-bold tracking-wider shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                             >
                                {isSavingConfig ? (
                                    <>
                                        <i className="fas fa-circle-notch fa-spin"></i> Saving & Reloading...
                                    </>
                                ) : (
                                    'Save & Connect'
                                )}
                             </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
      )}

      {/* Sync Toggle Confirmation Modal */}
      {showSyncConfirm && (
          <div className="fixed inset-0 bg-black/90 z-[95] flex items-center justify-center p-4 animate-[fadeIn_0.1s_ease-out]">
            <div className="bg-ghost-black border-[3px] border-spidey-blue w-full max-w-sm rounded-lg shadow-[0_0_30px_rgba(35,104,184,0.3)] animate-[zoomIn_0.1s_ease-out]">
                <div className="p-5 text-center">
                    <div className="mb-4 text-5xl text-spidey-blue animate-pulse">
                        <i className={`fas ${!cloudMode ? 'fa-cloud-upload-alt' : 'fa-hdd'}`}></i>
                    </div>
                    <h4 className="text-xl font-bold text-light uppercase mb-2">
                        Switch to {!cloudMode ? 'Cloud' : 'Local'}?
                    </h4>
                    <p className="text-gray-400 text-sm mb-6">
                        {!cloudMode 
                          ? "Connecting to Cloud Database..." 
                          : "Switching to Local Storage (Offline Mode)."}
                    </p>
                    
                    {!cloudMode && (
                        <div className="bg-dark/50 border border-gray-700 p-3 rounded mb-6 text-left">
                            <label className="flex items-start gap-3 cursor-pointer group">
                                <div className="relative flex items-center mt-0.5">
                                    <input 
                                        type="checkbox" 
                                        checked={syncOnSwitch}
                                        onChange={(e) => setSyncOnSwitch(e.target.checked)}
                                        className="w-4 h-4 accent-green-500 cursor-pointer"
                                    />
                                </div>
                                <div>
                                    <span className="block text-sm font-bold text-green-500 group-hover:text-green-400 transition-colors uppercase">
                                        Auto-Sync & Backup
                                    </span>
                                    <span className="block text-xs text-gray-500">
                                        Upload local wishes to cloud, and {backupMode === 'cloud' ? 'securely email download links' : 'download backup files'}.
                                    </span>
                                </div>
                            </label>
                        </div>
                    )}
                    
                    <div className="flex gap-3">
                        <button 
                            onClick={() => setShowSyncConfirm(false)}
                            className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold rounded uppercase tracking-wider transition-colors"
                        >
                            Cancel
                        </button>
                        <button 
                            onClick={executeSyncToggle}
                            className={`flex-1 py-3 text-white font-bold rounded uppercase tracking-wider transition-colors shadow-lg ${!cloudMode ? 'bg-green-600 hover:bg-green-500' : 'bg-gray-600 hover:bg-gray-500'}`}
                        >
                            {!cloudMode && syncOnSwitch ? 'Sync & Switch' : 'Confirm'}
                        </button>
                    </div>
                </div>
            </div>
          </div>
      )}

      {/* Email List Modal */}
      {showEmailModal && (
        <div className="fixed inset-0 bg-black/90 z-[90] flex items-center justify-center p-4 animate-[fadeIn_0.1s_ease-out]">
            <div className="bg-ghost-black border-[3px] border-yellow-500 w-full max-w-2xl rounded-lg shadow-[0_0_30px_rgba(234,179,8,0.3)] flex flex-col max-h-[80vh] animate-[zoomIn_0.1s_ease-out]">
                {/* Modal Header */}
                <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-ghost-black rounded-t-lg">
                    <h4 className="text-xl font-bold text-yellow-500 uppercase flex items-center gap-2">
                        <i className="fas fa-envelope-open-text"></i> Email Bank ({totalEmails})
                    </h4>
                    <button 
                        onClick={() => setShowEmailModal(false)}
                        className="text-gray-400 hover:text-white p-2"
                    >
                        <i className="fas fa-times text-xl"></i>
                    </button>
                </div>

                {/* Modal Actions */}
                <div className="p-4 bg-dark/50 border-b border-gray-800 flex flex-wrap gap-3">
                    <button 
                        onClick={handleBulkReply}
                        className="flex-1 bg-spidey-blue hover:bg-blue-600 text-white font-bold py-2 px-4 rounded uppercase tracking-wider transition-colors text-sm flex items-center justify-center gap-2"
                        title="Open email client with all users in BCC"
                    >
                        <i className="fas fa-paper-plane"></i> Reply All (BCC)
                    </button>
                    <button 
                        onClick={handleCopyEmails}
                        className="flex-1 bg-gray-700 hover:bg-gray-600 text-white font-bold py-2 px-4 rounded uppercase tracking-wider transition-colors text-sm flex items-center justify-center gap-2"
                    >
                        <i className="fas fa-copy"></i> {copyFeedback || 'Copy List'}
                    </button>
                </div>

                {/* Email List */}
                <div className="p-4 overflow-y-auto custom-scrollbar flex-1">
                    {uniqueEmails.length === 0 ? (
                        <p className="text-gray-500 text-center py-8">No emails collected yet.</p>
                    ) : (
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {uniqueEmails.map((email, idx) => (
                                <div key={idx} className="bg-dark p-2 rounded border border-gray-800 flex items-center gap-2 text-sm text-gray-300">
                                    <i className="fas fa-envelope text-yellow-500/50"></i>
                                    <span className="truncate" title={email}>{email}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
                
                <div className="p-3 bg-dark/30 text-center border-t border-gray-800">
                    <p className="text-xs text-gray-500">
                        <i className="fas fa-shield-alt mr-1"></i> 
                        "Reply All" uses Blind Carbon Copy (BCC) to protect user privacy.
                    </p>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
