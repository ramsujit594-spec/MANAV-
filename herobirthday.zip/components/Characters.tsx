import React from 'react';
import { CharacterConfig } from '../types';

const characters: CharacterConfig[] = [
  {
    id: 'spiderman',
    name: 'Manav',
    role: 'birthday boiii',
    description: 'With great power comes great responsibility. Your friendly neighborhood hero swings in to celebrate your special day!',
    icon: 'fa-spider',
    colorClass: 'text-spidey-blue',
    bgGradient: 'from-[rgba(35,104,184,0.2)] to-[rgba(212,32,41,0.3)]'
  },
  {
    id: 'ghost',
    name: 'Ghost',
    role: 'creator',
    description: 'The spectral spirit brings an ethereal presence to illuminate your birthday celebration with haunting energy!',
    icon: 'fa-ghost',
    colorClass: 'text-ghost-flame animate-pulse',
    bgGradient: 'from-[rgba(19,19,19,0.7)] to-[rgba(255,69,0,0.3)]'
  }
];

const Characters: React.FC = () => {
  return (
    <section id="characters" className="py-20 bg-ghost-black border-y-[3px] border-black">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-spidey-red uppercase inline-block relative mb-5">
            BIRTHDAY BOIIIII AND THE CREATOR
            <span className="absolute bottom-[-10px] left-0 w-full h-1 bg-gradient-to-r from-spidey-blue to-ghost-flame"></span>
          </h2>
          <p className="text-light text-xl">Celebrating with ghost flames and superhero powers</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          {characters.map((char, index) => (
            <div 
              key={char.id}
              className={`bg-dark rounded-lg p-8 shadow-hero border-[3px] border-black relative overflow-hidden group hover:-translate-y-2 hover:scale-[1.02] transition-transform duration-300 bg-gradient-to-br ${char.bgGradient}`}
            >
              {/* Radial Overlay */}
              <div className="absolute top-[-50%] left-[-50%] w-[200%] h-[200%] bg-[radial-gradient(circle,rgba(255,255,255,0.1)_0%,rgba(0,0,0,0)_70%)] rotate-45 z-0"></div>

              <div className={`relative z-10 text-5xl mb-5 ${char.colorClass}`}>
                <i className={`fas ${char.icon}`}></i>
              </div>

              <div className="relative z-10 w-full h-[300px] mb-5 border-[3px] border-black overflow-hidden rounded-md">
                 <img 
                   src={index === 0 ? "https://picsum.photos/600/600?random=10" : "https://picsum.photos/600/600?random=20"} 
                   alt={char.name} 
                   className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                 />
              </div>

              <h3 className={`relative z-10 text-3xl font-bold mb-4 ${char.id === 'spiderman' ? 'text-spidey-blue' : 'text-ghost-flame'}`}>
                {char.name}
              </h3>
              
              <p className="relative z-10 text-light text-lg mb-6 leading-relaxed">
                {char.description}
              </p>

              <div className="relative z-10 text-right font-bold text-light/80 uppercase tracking-widest border-t border-light/20 pt-4">
                {char.role}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Characters;