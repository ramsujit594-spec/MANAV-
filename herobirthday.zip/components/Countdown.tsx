import React, { useEffect, useState } from 'react';

const Countdown: React.FC = () => {
  const [timeLeft, setTimeLeft] = useState({
    days: '00',
    hours: '00',
    minutes: '00',
    seconds: '00'
  });

  useEffect(() => {
    const calculateTime = () => {
      const now = new Date();
      // Target Date: July 7, 2026
      // Note: Month is 0-indexed in JavaScript Date (0 = January, 6 = July)
      const targetDate = new Date(2026, 6, 7); 

      const diff = targetDate.getTime() - now.getTime();

      // If the date has passed, show zeros
      if (diff <= 0) {
        setTimeLeft({
          days: '00',
          hours: '00',
          minutes: '00',
          seconds: '00'
        });
        return;
      }

      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((diff % (1000 * 60)) / 1000);

      setTimeLeft({
        days: days.toString().padStart(2, '0'),
        hours: hours.toString().padStart(2, '0'),
        minutes: minutes.toString().padStart(2, '0'),
        seconds: seconds.toString().padStart(2, '0')
      });
    };

    calculateTime();
    const timer = setInterval(calculateTime, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <section id="countdown" className="py-20 bg-ghost-black border-y-[3px] border-black text-center">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-spidey-red uppercase inline-block relative mb-5">
            Birthday Countdown
          </h2>
          <p className="text-light text-xl">The celebration begins in...</p>
        </div>

        <div className="flex justify-center flex-wrap gap-5 mt-10">
          {Object.entries(timeLeft).map(([unit, value]) => (
            <div 
              key={unit} 
              className="bg-dark p-5 rounded-lg min-w-[120px] border-[3px] border-black shadow-hero transform hover:-translate-y-2 transition-transform"
            >
              <span className="block text-5xl font-bold text-spidey-red mb-2">
                {value}
              </span>
              <span className="text-sm font-bold text-light uppercase tracking-widest">{unit}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Countdown;