
import React, { useEffect, useState } from 'react';
import { isCloudSyncActive } from '../services/wishService';

interface FooterProps {
  isAdmin: boolean;
}

const Footer: React.FC<FooterProps> = ({ isAdmin }) => {
  const [isSynced, setIsSynced] = useState(false);

  useEffect(() => {
    setIsSynced(isCloudSyncActive());
  }, []);

  const socialLinks = [
    { name: 'instagram', url: 'https://www.instagram.com/mnv_rwt?igsh=amEwMTZ1a3V3cDNq', label: 'MANAV' },
    { name: 'instagram', url: 'https://www.instagram.com/06._.ghost?igsh=bzlrNmxhZm5od3B4', label: 'GHOST' }
  ];

  return (
    <footer className="bg-ghost-black text-white pt-16 pb-6 border-t-[3px] border-black">
      <div className="max-w-[1200px] mx-auto px-5 text-center">
        <div className="mb-10">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-spidey-red to-ghost-flame bg-clip-text text-transparent inline-block mb-4">
            HeroBirthday
          </h2>
          <p className="text-light/80 max-w-md mx-auto">
            May your birthday be as amazing as a team-up between Manav and Ghost!
          </p>
        </div>

        <div className="flex justify-center gap-8 mb-10">
          {socialLinks.map((social, index) => (
            <div key={index} className="flex flex-col items-center gap-2">
              <a 
                href={social.url}
                target={social.url !== '#' ? "_blank" : "_self"}
                rel={social.url !== '#' ? "noopener noreferrer" : ""}
                className="w-12 h-12 flex items-center justify-center rounded-full bg-dark border-2 border-gray-800 text-light text-xl hover:text-spidey-red hover:-translate-y-1 hover:border-spidey-red transition-all duration-300"
              >
                <i className={`fab fa-${social.name}`}></i>
              </a>
              {social.label && (
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">{social.label}</span>
              )}
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-col items-center gap-2">
          <p className="text-gray-500 text-sm">
            Designed with <i className="fas fa-heart text-ghost-flame mx-1 animate-pulse"></i> for the birthday boii | &copy; 2024 Superhero Celebration
          </p>
          
          {/* Sync Status Indicator - ONLY VISIBLE IN ADMIN MODE */}
          {isAdmin && (
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest mt-2 bg-dark/50 px-3 py-1 rounded-full border border-white/5">
              <span className={`w-2 h-2 rounded-full ${isSynced ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`}></span>
              <span className={isSynced ? 'text-green-500' : 'text-yellow-500'}>
                {isSynced ? 'Live Sync Active' : 'Local Mode'}
              </span>
            </div>
          )}
        </div>
      </div>
    </footer>
  );
};

export default Footer;