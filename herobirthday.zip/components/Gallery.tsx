import React from 'react';
import { GalleryItem } from '../types';

const galleryItems: GalleryItem[] = [
  { id: 1, src: "https://picsum.photos/400/400?random=1", alt: "Spider-Man web-slinging" },
  { id: 2, src: "https://picsum.photos/400/400?random=2", alt: "Ghost floating" },
  { id: 3, src: "https://picsum.photos/400/400?random=3", alt: "Team up battle" },
  { id: 4, src: "https://picsum.photos/400/400?random=4", alt: "Birthday cake" },
  { id: 5, src: "https://picsum.photos/400/400?random=5", alt: "Confetti celebration" },
  { id: 6, src: "https://picsum.photos/400/400?random=6", alt: "Fiery transformation" },
];

const Gallery: React.FC = () => {
  return (
    <section id="gallery" className="py-20 bg-dark">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold text-spidey-red uppercase inline-block relative mb-5">
            Manav Moments
            <span className="absolute bottom-[-10px] left-0 w-full h-1 bg-gradient-to-r from-spidey-blue to-ghost-flame"></span>
          </h2>
          <p className="text-light text-xl">Capturing the action-packed celebration</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 mt-10">
          {galleryItems.map((item) => (
            <div 
              key={item.id} 
              className="relative overflow-hidden rounded-lg border-[3px] border-black h-[250px] group transition-transform duration-300 hover:scale-105 hover:z-10 shadow-hero"
            >
              <img 
                src={item.src} 
                alt={item.alt} 
                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors"></div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Gallery;