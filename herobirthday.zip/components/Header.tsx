
import React, { useState } from 'react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen);

  const navLinks = [
    { name: 'Home', href: '#' },
    { name: 'Heroes', href: '#characters' },
    { name: 'Gallery', href: '#gallery' },
    { name: 'Countdown', href: '#countdown' },
    { name: 'Wishes', href: '#wishes' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  return (
    <header className="fixed w-full top-0 z-50 bg-ghost-black border-b-[3px] border-black shadow-hero">
      <div className="max-w-[1200px] mx-auto px-5">
        <nav className="flex justify-between items-center py-4">
          <a href="#" className="font-bold text-3xl bg-gradient-to-r from-spidey-red to-ghost-flame bg-clip-text text-transparent drop-shadow-md">
            HeroBirthday
          </a>

          {/* Desktop Nav */}
          <div className="hidden md:flex gap-6 items-center">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="text-light font-bold uppercase tracking-wider relative hover:text-spidey-red transition-colors duration-300 group"
              >
                {link.name}
                <span className="absolute bottom-[-5px] left-0 w-0 h-[3px] bg-spidey-red transition-all duration-300 group-hover:w-full"></span>
              </a>
            ))}
          </div>

          {/* Mobile Hamburger */}
          <div className="flex gap-4 items-center md:hidden">
            <div className="cursor-pointer text-light text-2xl" onClick={toggleMenu}>
              <i className={`fas ${isMenuOpen ? 'fa-times' : 'fa-bars'}`}></i>
            </div>
          </div>
        </nav>
      </div>

      {/* Mobile Nav Menu */}
      <div className={`md:hidden absolute w-full bg-ghost-black border-t-[3px] border-black shadow-hero transition-all duration-300 ease-in-out ${isMenuOpen ? 'top-full opacity-100' : '-top-[500px] opacity-0'}`}>
        <div className="flex flex-col p-5 gap-4">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              onClick={(e) => handleNavClick(e, link.href)}
              className="text-light font-bold uppercase tracking-wider hover:text-spidey-red"
            >
              {link.name}
            </a>
          ))}
        </div>
      </div>
    </header>
  );
};

export default Header;