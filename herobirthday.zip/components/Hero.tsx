import React from 'react';

const Hero: React.FC = () => {
  const scrollToWishes = (e: React.MouseEvent<HTMLAnchorElement>) => {
    e.preventDefault();
    const wishesSection = document.getElementById('wishes');
    if (wishesSection) {
      wishesSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="relative min-h-[85vh] flex items-center justify-center text-center pt-[150px] pb-12 overflow-hidden bg-dark">
      {/* Background Image Overlay */}
      <div className="absolute inset-0 z-0">
        <div 
          className="w-full h-full bg-cover bg-center bg-no-repeat opacity-60"
          style={{ backgroundImage: "url('https://storage.googleapis.com/workspace-0f70711f-8b4e-4d94-86f1-2a93ccde5887/image/69771574-0028-4563-b0b3-63a8804530c4.png')" }}
        ></div>
        <div className="absolute inset-0 bg-gradient-to-b from-dark/70 to-dark/90"></div>
      </div>

      <div className="relative z-10 max-w-[800px] mx-auto px-5">
        <h1 className="text-4xl md:text-6xl font-bold mb-5 bg-gradient-to-r from-spidey-blue to-spidey-red bg-clip-text text-transparent drop-shadow-lg animate-[zoomIn_1s_ease-out]">
          MANAV & GHOST BIRTHDAY BASH
        </h1>
        
        <div className="text-3xl md:text-5xl font-bold text-ghost-flame mb-6 uppercase animate-flame">
          HAPPY BIRTHDAY MANAV!
        </div>
        
        <p className="text-xl md:text-2xl text-light drop-shadow-md mb-8">
          Your special day just got a superhero team-up with Manav's powers and the spectral might of Ghost!
        </p>

        <a 
          href="#wishes"
          onClick={scrollToWishes}
          className="inline-block px-8 py-3 bg-spidey-red text-white font-bold uppercase tracking-wider border-[3px] border-black hover:bg-red-700 hover:-translate-y-1 transition-transform shadow-[4px_4px_0px_0px_rgba(255,255,255,0.2)]"
        >
          Send A Wish
        </a>
      </div>
    </section>
  );
};

export default Hero;