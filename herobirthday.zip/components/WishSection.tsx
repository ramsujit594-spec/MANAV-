
import React, { useState, useEffect } from 'react';
import { Wish, HeroCharacter } from '../types';
import { subscribeToWishes, createWish, deleteWish, clearAllWishes, updateWishReply, subscribeToVisitorCount, updateWishCharacter, updateWishTheme, updateWishDetails, isCloudSyncActive } from '../services/wishService';
import { generateAiWish } from '../services/geminiService';
import AdminDashboard from './AdminDashboard';

interface HeroOption {
  id: HeroCharacter;
  label: string;
  icon: string;
  color: string;
  border: string;
  bg: string;
  hex: string;
}

const heroOptions: HeroOption[] = [
  { 
    id: 'spiderman', 
    label: 'Spider-Man', 
    icon: 'fas fa-spider', 
    color: 'text-spidey-blue', 
    border: 'border-spidey-blue', 
    bg: 'bg-spidey-blue/20',
    hex: '#2368B8'
  },
  { 
    id: 'ghost', 
    label: 'Ghost', 
    icon: 'fas fa-ghost', 
    color: 'text-ghost-flame', 
    border: 'border-ghost-flame', 
    bg: 'bg-ghost-flame/20',
    hex: '#FF4500'
  },
  { 
    id: 'ironman', 
    label: 'Iron Man', 
    icon: 'fas fa-robot', 
    color: 'text-yellow-500', 
    border: 'border-yellow-500', 
    bg: 'bg-yellow-500/20',
    hex: '#EAB308'
  },
  { 
    id: 'captainamerica', 
    label: 'Captain America', 
    icon: 'fas fa-shield-alt', 
    color: 'text-blue-500', 
    border: 'border-blue-500', 
    bg: 'bg-blue-500/20',
    hex: '#3B82F6'
  },
  { 
    id: 'deadpool', 
    label: 'Deadpool', 
    icon: 'fas fa-mask', 
    color: 'text-red-600', 
    border: 'border-red-600', 
    bg: 'bg-red-600/20',
    hex: '#DC2626'
  },
  { 
    id: 'hulk', 
    label: 'Hulk', 
    icon: 'fas fa-fist-raised', 
    color: 'text-green-600', 
    border: 'border-green-600', 
    bg: 'bg-green-600/20',
    hex: '#16A34A'
  },
  { 
    id: 'thor', 
    label: 'Thor', 
    icon: 'fas fa-hammer', 
    color: 'text-yellow-400', 
    border: 'border-yellow-400', 
    bg: 'bg-yellow-400/20',
    hex: '#FACC15'
  },
  { 
    id: 'doctorstrange', 
    label: 'Dr. Strange', 
    icon: 'fas fa-hand-sparkles', 
    color: 'text-purple-600', 
    border: 'border-purple-600', 
    bg: 'bg-purple-600/20',
    hex: '#9333EA'
  },
  { 
    id: 'batman', 
    label: 'Batman', 
    icon: 'fas fa-user-secret', 
    color: 'text-gray-400', 
    border: 'border-gray-400', 
    bg: 'bg-gray-400/20',
    hex: '#9CA3AF'
  },
  { 
    id: 'wolverine', 
    label: 'Wolverine', 
    icon: 'fab fa-firefox', 
    color: 'text-orange-500', 
    border: 'border-orange-500', 
    bg: 'bg-orange-500/20',
    hex: '#F97316'
  },
  { 
    id: 'blackpanther', 
    label: 'Black Panther', 
    icon: 'fas fa-paw', 
    color: 'text-violet-500', 
    border: 'border-violet-500', 
    bg: 'bg-violet-500/20',
    hex: '#8B5CF6'
  },
  { 
    id: 'wonderwoman', 
    label: 'Wonder Woman', 
    icon: 'fas fa-crown', 
    color: 'text-rose-500', 
    border: 'border-rose-500', 
    bg: 'bg-rose-500/20',
    hex: '#F43F5E'
  },
  { 
    id: 'flash', 
    label: 'The Flash', 
    icon: 'fas fa-bolt', 
    color: 'text-red-500', 
    border: 'border-red-500', 
    bg: 'bg-red-500/20',
    hex: '#EF4444'
  },
  { 
    id: 'aquaman', 
    label: 'Aquaman', 
    icon: 'fas fa-water', 
    color: 'text-cyan-400', 
    border: 'border-cyan-400', 
    bg: 'bg-cyan-400/20',
    hex: '#22D3EE'
  },
  { 
    id: 'groot', 
    label: 'Groot', 
    icon: 'fas fa-tree', 
    color: 'text-green-800', 
    border: 'border-green-800', 
    bg: 'bg-green-800/20',
    hex: '#166534'
  }
];

interface WishSectionProps {
  isAdmin: boolean;
  setIsAdmin: (isAdmin: boolean) => void;
}

const WishSection: React.FC<WishSectionProps> = ({ isAdmin, setIsAdmin }) => {
  const [wishes, setWishes] = useState<Wish[]>([]);
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [selectedChar, setSelectedChar] = useState<HeroCharacter>('spiderman');
  const [selectedTheme, setSelectedTheme] = useState<HeroCharacter>('spiderman');
  const [isThemeOpen, setIsThemeOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isGeneratingWish, setIsGeneratingWish] = useState(false);
  const [myWishIds, setMyWishIds] = useState<string[]>([]);
  const [visitorCount, setVisitorCount] = useState(0);
  
  // Sync Mode State (Default to available cloud status)
  const [cloudMode, setCloudMode] = useState(isCloudSyncActive());
  
  // Theme Animation State
  const [themeAnim, setThemeAnim] = useState<HeroCharacter | null>(null);

  // Expanded Wishes State
  const [expandedWishes, setExpandedWishes] = useState<Set<string>>(new Set());
  
  // Admin Login States
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [adminPasswordInput, setAdminPasswordInput] = useState('');
  const [isLockedOut, setIsLockedOut] = useState(false);

  // Admin Reply States
  const [replyingToId, setReplyingToId] = useState<string | null>(null);
  const [replyContent, setReplyContent] = useState('');
  const [isSubmittingReply, setIsSubmittingReply] = useState(false);

  // Edit State (Hero/Theme)
  const [editModal, setEditModal] = useState<{
      show: boolean;
      wishId: string;
      type: 'hero' | 'theme';
  }>({ show: false, wishId: '', type: 'hero' });

  // Content Edit State (Name/Email/Message)
  const [contentEditModal, setContentEditModal] = useState<{
    show: boolean;
    wishId: string;
    name: string;
    email: string;
    message: string;
  }>({ show: false, wishId: '', name: '', email: '', message: '' });

  // Confirmation Modal State
  const [confirmModal, setConfirmModal] = useState<{
    show: boolean;
    type: 'delete' | 'clear' | 'logout' | 'edit';
    targetId?: string;
  }>({ show: false, type: 'delete' });

  const MAX_ATTEMPTS = 3;
  const LOCKOUT_DURATION = 24 * 60 * 60 * 1000; // 24 hours
  const MY_WISHES_KEY = 'hero_my_wishes';

  useEffect(() => {
    checkLockoutStatus();
    loadMyWishes();
    
    // Subscribe to Real-Time Updates based on cloudMode
    setIsLoading(true);
    const unsubscribeWishes = subscribeToWishes((updatedWishes) => {
      setWishes(updatedWishes);
      setIsLoading(false);
    }, cloudMode);

    const unsubscribeVisitors = subscribeToVisitorCount((count) => {
      setVisitorCount(count);
    }, cloudMode);
    
    return () => {
      unsubscribeWishes();
      unsubscribeVisitors();
    };
  }, [cloudMode]); // Re-run when toggle changes

  const loadMyWishes = () => {
    const stored = localStorage.getItem(MY_WISHES_KEY);
    if (stored) {
      try {
        setMyWishIds(JSON.parse(stored));
      } catch (e) {
        setMyWishIds([]);
      }
    }
  };

  const checkLockoutStatus = () => {
    const lockoutTimeStr = localStorage.getItem('hero_admin_lockout_time');
    if (lockoutTimeStr) {
      const lockoutTime = parseInt(lockoutTimeStr, 10);
      if (Date.now() - lockoutTime < LOCKOUT_DURATION) {
        setIsLockedOut(true);
      } else {
        localStorage.removeItem('hero_admin_lockout_time');
        localStorage.removeItem('hero_admin_attempts');
        setIsLockedOut(false);
      }
    }
  };

  const toggleWish = (id: string) => {
    setExpandedWishes(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleAiGen = async () => {
    setIsGeneratingWish(true);
    const wishText = await generateAiWish(selectedChar);
    setMessage(wishText);
    setIsGeneratingWish(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    setIsSubmitting(true);
    try {
      const newWish = await createWish(name, message, selectedChar, selectedTheme, email, cloudMode);
      
      const updatedMyIds = [...myWishIds, newWish.id];
      setMyWishIds(updatedMyIds);
      localStorage.setItem(MY_WISHES_KEY, JSON.stringify(updatedMyIds));

      setExpandedWishes(prev => {
        const next = new Set(prev);
        next.add(newWish.id);
        return next;
      });

      setName('');
      setEmail('');
      setMessage('');
      
    } catch (error) {
      console.error("Failed to submit wish", error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const requestDelete = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    setConfirmModal({ show: true, type: 'delete', targetId: id });
  };

  const requestClearAll = () => {
    setConfirmModal({ show: true, type: 'clear' });
  };

  const handleBadgeClick = (e: React.MouseEvent, wishId: string, type: 'hero' | 'theme') => {
      e.stopPropagation();
      setEditModal({ show: true, wishId, type });
  };

  const handleEditContentClick = (wish: Wish, e: React.MouseEvent) => {
      e.stopPropagation();
      setContentEditModal({
        show: true,
        wishId: wish.id,
        name: wish.name,
        email: wish.email || '',
        message: wish.message
      });
  };

  const handleContentEditSubmit = (e: React.FormEvent) => {
      e.preventDefault();
      setConfirmModal({ show: true, type: 'edit' });
  };

  const handleThemeSelect = (heroId: HeroCharacter) => {
    setSelectedTheme(heroId);
    setIsThemeOpen(false);
    setThemeAnim(heroId);
    setTimeout(() => setThemeAnim(null), 1200);
  };

  const handleEditSelect = async (newId: HeroCharacter) => {
      if (editModal.type === 'hero') {
          await updateWishCharacter(editModal.wishId, newId, cloudMode);
      } else {
          await updateWishTheme(editModal.wishId, newId, cloudMode);
          setThemeAnim(newId);
          setTimeout(() => setThemeAnim(null), 1200);
      }
      setEditModal({ ...editModal, show: false });
  };

  const executeAction = async () => {
    if (confirmModal.type === 'delete' && confirmModal.targetId) {
        const id = confirmModal.targetId;
        
        setWishes(prevWishes => prevWishes.filter(w => w.id !== id));
        
        if (myWishIds.includes(id)) {
            const updatedMyIds = myWishIds.filter(mid => mid !== id);
            setMyWishIds(updatedMyIds);
            localStorage.setItem(MY_WISHES_KEY, JSON.stringify(updatedMyIds));
        }
        
        try {
          await deleteWish(id, cloudMode);
        } catch (error) {
          console.error("Failed to delete wish", error);
        }
    } 
    else if (confirmModal.type === 'clear') {
        setWishes([]);
        setMyWishIds([]); 
        localStorage.removeItem(MY_WISHES_KEY);
        await clearAllWishes(cloudMode);
    }
    else if (confirmModal.type === 'logout') {
        setIsAdmin(false);
        setReplyingToId(null);
    }
    else if (confirmModal.type === 'edit') {
        await updateWishDetails(contentEditModal.wishId, {
            name: contentEditModal.name,
            email: contentEditModal.email,
            message: contentEditModal.message
        }, cloudMode);
        setContentEditModal({ ...contentEditModal, show: false });
    }
    
    setConfirmModal({ ...confirmModal, show: false });
  };

  const handleLockClick = () => {
    if (isAdmin) {
      setConfirmModal({ show: true, type: 'logout' });
      return;
    }
    setShowLoginModal(true);
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPasswordInput === '707') {
      setIsAdmin(true);
      setShowLoginModal(false);
      setAdminPasswordInput('');
      localStorage.removeItem('hero_admin_attempts');
    } else {
      const currentAttemptsStr = localStorage.getItem('hero_admin_attempts');
      let attempts = currentAttemptsStr ? parseInt(currentAttemptsStr, 10) : 0;
      attempts += 1;
      localStorage.setItem('hero_admin_attempts', attempts.toString());
      
      if (attempts >= MAX_ATTEMPTS) {
        alert("Too many incorrect attempts. Admin access locked for 24 hours.");
        localStorage.setItem('hero_admin_lockout_time', Date.now().toString());
        setIsLockedOut(true);
        setShowLoginModal(false);
      } else {
        alert(`Incorrect password. ${MAX_ATTEMPTS - attempts} attempts remaining.`);
        setAdminPasswordInput('');
      }
    }
  };

  const handleReplyClick = (wish: Wish, e: React.MouseEvent) => {
    e.stopPropagation();
    setReplyingToId(wish.id);
    setReplyContent(wish.adminReply || '');
  };

  const handleCancelReply = (e: React.MouseEvent) => {
    e.stopPropagation();
    setReplyingToId(null);
    setReplyContent('');
  };

  const handleReplySubmit = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!replyContent.trim()) return;
    setIsSubmittingReply(true);
    try {
        setWishes(prev => prev.map(w => w.id === id ? { ...w, adminReply: replyContent } : w));
        await updateWishReply(id, replyContent, cloudMode);
        setReplyingToId(null);
        setReplyContent('');
    } catch (error) {
        console.error("Failed to save reply", error);
    } finally {
        setIsSubmittingReply(false);
    }
  };

  const getHeroConfig = (id: HeroCharacter) => heroOptions.find(h => h.id === id) || heroOptions[0];

  const gradientBorderStyle = {
    border: '3px solid transparent',
    backgroundImage: `linear-gradient(#131313, #131313), linear-gradient(to right, #2368B8, #FF4500)`,
    backgroundOrigin: 'border-box',
    backgroundClip: 'padding-box, border-box',
    boxShadow: '0 0 10px rgba(35, 104, 184, 0.2)'
  };

  const getConfirmationText = () => {
      switch(confirmModal.type) {
          case 'clear': return "CRITICAL WARNING: This will permanently delete ALL wishes for everyone. Are you absolutely sure?";
          case 'delete': return "Are you sure you want to delete this wish? This action cannot be undone.";
          case 'logout': return "Are you sure you want to log out of Admin Mode?";
          case 'edit': return "Are you sure you want to save changes to this wish?";
          default: return "";
      }
  };

  const getModalIcon = () => {
      switch(confirmModal.type) {
          case 'logout': return 'fa-sign-out-alt';
          case 'edit': return 'fa-save';
          default: return 'fa-exclamation-triangle';
      }
  };

  const getModalColorClass = () => {
      switch(confirmModal.type) {
          case 'logout': return 'text-spidey-blue';
          case 'edit': return 'text-yellow-500';
          default: return 'text-red-500';
      }
  };

  const getModalBorderClass = () => {
      switch(confirmModal.type) {
          case 'logout': return 'border-spidey-blue';
          case 'edit': return 'border-yellow-500';
          default: return 'border-red-600';
      }
  };

  const getModalButtonBg = () => {
      switch(confirmModal.type) {
          case 'logout': return 'bg-spidey-blue hover:bg-blue-600';
          case 'edit': return 'bg-yellow-500 hover:bg-yellow-400 text-black';
          default: return 'bg-red-600 hover:bg-red-700';
      }
  };

  return (
    <section id="wishes" className="py-20 bg-dark relative">
      <div className="max-w-[1200px] mx-auto px-5">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          
          {/* Form Side */}
          <div className="bg-ghost-black p-8 rounded-lg border-[3px] border-black shadow-hero h-fit">
            <h3 className="text-3xl font-bold text-spidey-blue mb-2 uppercase">Leave a Wish</h3>
            <p className="text-gray-400 mb-6">Choose your hero avatar, pick a card theme, and send a message to the birthday boi!</p>
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <label className="block text-light font-bold mb-2 uppercase text-sm">Pick Your Hero</label>
                <div className="grid grid-cols-3 sm:grid-cols-4 lg:grid-cols-5 gap-3">
                  {heroOptions.map((hero) => {
                    const isSelected = selectedChar === hero.id;
                    return (
                      <button
                        key={hero.id}
                        type="button"
                        onClick={() => setSelectedChar(hero.id)}
                        className={`relative rounded-md transition-all duration-300 ease-out flex flex-col items-center justify-center gap-1 min-h-[80px] w-full
                        ${isSelected 
                          ? 'scale-105 z-10 shadow-[0_0_15px_rgba(255,255,255,0.1)]' 
                          : 'border-[3px] border-gray-700 bg-dark opacity-60 hover:opacity-100 hover:border-gray-500 hover:scale-105 hover:shadow-lg hover:-translate-y-1'
                        }`}
                        style={isSelected ? gradientBorderStyle : {}}
                      >
                        <i className={`${hero.icon} text-xl ${isSelected ? hero.color : 'text-gray-400'} transition-colors duration-300`}></i>
                        <span className={`font-bold text-[10px] sm:text-xs text-center leading-tight ${isSelected ? 'text-light' : 'text-gray-400'} transition-colors duration-300`}>{hero.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <label className="block text-light font-bold mb-2 uppercase text-sm">
                  Choose Theme <span className="text-gray-500 text-xs normal-case ml-1">(Card Style)</span>
                </label>
                
                <div className="relative">
                  {isThemeOpen && (
                    <div className="fixed inset-0 z-10" onClick={() => setIsThemeOpen(false)}></div>
                  )}
                  
                  <button
                    type="button"
                    onClick={() => setIsThemeOpen(!isThemeOpen)}
                    className="w-full text-light p-3 rounded focus:outline-none transition-colors flex items-center justify-between text-left relative z-20 bg-ghost-black"
                    style={gradientBorderStyle}
                  >
                    <div className="flex items-center gap-3">
                       {(() => {
                         const current = getHeroConfig(selectedTheme);
                         return (
                           <>
                             <i className={`${current.icon} ${current.color} w-6 text-center text-lg`}></i>
                             <span>{current.label} Theme</span>
                           </>
                         );
                       })()}
                    </div>
                    <div className="text-light">
                      <i className={`fas fa-chevron-down text-xs transition-transform duration-200 ${isThemeOpen ? 'rotate-180' : ''}`}></i>
                    </div>
                  </button>

                  {isThemeOpen && (
                    <div className="absolute z-30 w-full mt-1 bg-ghost-black border-[2px] border-gray-700 rounded shadow-xl max-h-60 overflow-y-auto custom-scrollbar">
                      {heroOptions.map(hero => (
                        <div
                          key={hero.id}
                          onClick={() => handleThemeSelect(hero.id)}
                          className={`p-3 cursor-pointer flex items-center gap-3 transition-colors border-b border-gray-800 last:border-0 hover:bg-white/5 ${selectedTheme === hero.id ? 'bg-white/10' : ''}`}
                        >
                           <i className={`${hero.icon} ${hero.color} w-6 text-center text-lg`}></i>
                           <span className="text-light">{hero.label} Theme</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-light font-bold mb-2 uppercase text-sm">Your Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full bg-dark text-light border-[2px] border-gray-700 p-3 rounded focus:border-spidey-red focus:outline-none transition-colors"
                  placeholder="Enter your name..."
                  required
                />
              </div>

              <div>
                <label className="block text-light font-bold mb-2 uppercase text-sm">
                  Your Email <span className="text-gray-500 text-xs normal-case ml-1">(Optional)</span>
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-dark text-light border-[2px] border-gray-700 p-3 rounded focus:border-spidey-red focus:outline-none transition-colors"
                  placeholder="Enter your email..."
                />
              </div>

              <div>
                <label className="block text-light font-bold mb-2 uppercase text-sm">Your Wish</label>
                <div className="relative">
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    className="w-full bg-dark text-light border-[2px] border-gray-700 p-3 rounded h-32 focus:border-ghost-flame focus:outline-none transition-colors pb-10"
                    placeholder="Write something heroic..."
                    required
                  ></textarea>
                  <button
                    type="button"
                    onClick={handleAiGen}
                    disabled={isGeneratingWish}
                    className="absolute bottom-3 right-3 text-xs bg-ghost-flame text-white px-3 py-1.5 rounded-full hover:bg-orange-600 transition-colors flex items-center gap-1.5 shadow-md disabled:opacity-50 border border-white/10"
                    title="Auto-generate with AI based on selected hero"
                  >
                    {isGeneratingWish ? (
                      <i className="fas fa-spinner fa-spin"></i>
                    ) : (
                      <i className="fas fa-magic"></i>
                    )}
                    <span>AI Magic</span>
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-4 bg-spidey-red text-white font-bold uppercase tracking-wider border-[3px] border-black hover:bg-red-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <i className="fas fa-circle-notch fa-spin"></i> Sending to HQ...
                  </>
                ) : (
                  <>Send Wish</>
                )}
              </button>
              <p className="text-xs text-center text-gray-500 mt-2">
                *Uses {cloudMode ? 'Cloud Database' : 'Local Storage'} & Gemini API
              </p>
            </form>
          </div>

          {/* List Side */}
          <div>
            <div className="flex justify-between items-center mb-6 flex-wrap gap-2">
                <div className="flex items-center gap-3">
                  <h3 className="text-3xl font-bold text-ghost-flame uppercase lg:text-left">
                  Wishes
                  </h3>
                  {!isLockedOut && (
                    <button 
                      onClick={handleLockClick}
                      className={`text-sm p-1 rounded transition-colors ${isAdmin ? 'text-green-500 hover:text-green-400' : 'text-gray-600 hover:text-gray-400'}`}
                      title={isAdmin ? "Admin Mode Active (Click to Logout)" : "Admin Login"}
                    >
                      <i className={`fas ${isAdmin ? 'fa-unlock' : 'fa-lock'}`}></i>
                    </button>
                  )}
                </div>

                <div className="flex gap-2">
                    {isAdmin && wishes.length > 0 && (
                        <button 
                            onClick={requestClearAll}
                            className="text-xs text-red-500 hover:text-red-400 border border-red-900 bg-red-900/20 px-3 py-1 rounded uppercase tracking-widest transition-colors"
                        >
                            Clear All
                        </button>
                    )}
                </div>
            </div>
            
            <div className="space-y-6 max-h-[800px] overflow-y-auto pr-2 custom-scrollbar p-1">
              {isLoading ? (
                <div className="text-center text-light py-10 flex flex-col items-center gap-2">
                    <i className="fas fa-circle-notch fa-spin text-2xl text-spidey-blue"></i>
                    <span>Connecting to {cloudMode ? 'Cloud' : 'Local'} HQ...</span>
                </div>
              ) : wishes.length === 0 ? (
                <div className="text-center text-gray-500 py-10 border-2 border-dashed border-gray-800 rounded-lg">
                  No wishes yet in {cloudMode ? 'Cloud' : 'Local'} storage. Be the first hero!
                </div>
              ) : (
                wishes.map((wish) => {
                  const themeConfig = getHeroConfig(wish.theme || wish.character);
                  const charConfig = getHeroConfig(wish.character);
                  const isReplying = replyingToId === wish.id;
                  
                  const isOpen = expandedWishes.has(wish.id) || isReplying;

                  const isMine = myWishIds.includes(wish.id);
                  const canDelete = isAdmin || isMine;
                  const canReply = isAdmin;
                  const canEdit = canDelete; 

                  return (
                    <div 
                      key={wish.id} 
                      onClick={() => toggleWish(wish.id)}
                      className="bg-ghost-black p-6 rounded-lg border-l-[6px] border-y border-r border-gray-800 shadow-md relative overflow-hidden group hover:-translate-y-1 hover:shadow-xl transition-all duration-300 animate-fade-in-up cursor-pointer opacity-0" 
                      style={{ borderLeftColor: themeConfig.hex, animationDelay: '0s', opacity: 1 }}
                    >
                      <div className={`absolute inset-0 opacity-0 group-hover:opacity-5 transition-opacity duration-300 ${themeConfig.bg}`}></div>

                      {(canDelete || canReply) && (
                        <div className="absolute top-2 right-2 flex gap-2 z-20" onClick={(e) => e.stopPropagation()}>
                            {canReply && (
                                <button 
                                  onClick={(e) => handleReplyClick(wish, e)}
                                  className="text-gray-400 hover:text-spidey-blue p-2 rounded-full hover:bg-black/40 transition-all"
                                  title="Reply to Wish"
                                >
                                  <i className="fas fa-reply"></i>
                                </button>
                            )}
                            {canEdit && (
                                <button 
                                  onClick={(e) => handleEditContentClick(wish, e)}
                                  className="text-gray-400 hover:text-yellow-500 p-2 rounded-full hover:bg-black/40 transition-all"
                                  title="Edit Wish"
                                >
                                  <i className="fas fa-pen"></i>
                                </button>
                            )}
                            {canDelete && (
                                <button 
                                  onClick={(e) => requestDelete(wish.id, e)}
                                  className="text-gray-400 hover:text-red-500 p-2 rounded-full hover:bg-black/40 transition-all"
                                  title="Delete Wish"
                                >
                                  <i className="fas fa-trash"></i>
                                </button>
                            )}
                        </div>
                      )}

                      <div className="relative z-10 flex justify-between items-start mb-4">
                        <div className="flex items-center gap-4">
                          <div className={`w-12 h-12 rounded-full flex items-center justify-center border-[2px] border-black bg-dark shadow-sm shrink-0`}>
                            <i className={`${charConfig.icon} ${charConfig.color} text-xl`}></i>
                          </div>
                          <div>
                            <h4 className="font-bold text-light text-lg leading-tight">{wish.name}</h4>
                            <span className="text-xs text-gray-500 font-mono">
                              {new Date(wish.timestamp).toLocaleDateString(undefined, { 
                                year: 'numeric', 
                                month: 'short', 
                                day: 'numeric'
                              })}
                            </span>
                            {isAdmin && wish.email && (
                              <a 
                                href={`mailto:${wish.email}`}
                                onClick={(e) => e.stopPropagation()} 
                                className="flex items-center gap-2 mt-1 text-xs text-yellow-500/80 font-mono hover:text-yellow-400 hover:underline transition-colors w-fit" 
                                title="Click to send email (Visible only to Admin)"
                              >
                                <i className="fas fa-envelope"></i>
                                <span>{wish.email}</span>
                              </a>
                            )}
                          </div>
                        </div>
                        
                        {wish.theme && wish.theme !== wish.character && (
                            <div 
                                onClick={(e) => canEdit && handleBadgeClick(e, wish.id, 'theme')}
                                className={`flex items-center gap-2 px-3 py-1 rounded-full border ${themeConfig.border} bg-dark/60 backdrop-blur-sm shadow-sm opacity-60 group-hover:opacity-100 transition-all duration-300 mr-14 md:mr-28 ${canEdit ? 'cursor-pointer hover:scale-105 hover:bg-white/10' : ''}`} 
                                title={`Theme: ${themeConfig.label} ${canEdit ? '(Click to Change)' : ''}`}
                            >
                                 <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider">Theme</span>
                                 <i className={`${themeConfig.icon} ${themeConfig.color} text-sm`}></i>
                            </div>
                        )}
                      </div>
                      
                      <div className="relative z-10 pl-16">
                          <div className="flex flex-wrap gap-2 mb-3">
                              <div 
                                onClick={(e) => canEdit && handleBadgeClick(e, wish.id, 'hero')}
                                className={`flex items-center gap-2 px-2 py-0.5 rounded-full border ${charConfig.border} bg-dark/40 opacity-80 ${canEdit ? 'cursor-pointer hover:scale-105 hover:bg-white/10' : ''}`}
                                title={`Hero: ${charConfig.label} ${canEdit ? '(Click to Change)' : ''}`}
                              >
                                   <i className={`${charConfig.icon} ${charConfig.color} text-xs`}></i>
                                   <span className={`text-[10px] uppercase font-bold ${charConfig.color}`}>Hero: {charConfig.label}</span>
                              </div>
                          </div>

                          <i className="fas fa-quote-left text-gray-700 text-sm mb-2 block"></i>
                          
                          <p className={`text-gray-200 text-base leading-relaxed whitespace-pre-wrap transition-all duration-300 ${isOpen ? 'mb-5' : 'mb-2 line-clamp-2 overflow-hidden text-ellipsis'}`}>
                            "{wish.message}"
                          </p>

                          <div 
                             className={`grid transition-[grid-template-rows] duration-500 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
                          >
                             <div className="overflow-hidden">
                                  {wish.aiResponse ? (
                                    <div className={`mt-3 p-4 rounded-r-lg rounded-bl-lg border-l-[4px] relative overflow-hidden transition-all duration-300 ${charConfig.bg} ${charConfig.border} ${wish.aiResponse.includes('Message received') ? 'animate-pulse' : ''}`}>
                                        <div className="absolute -right-3 -bottom-3 text-5xl opacity-10 pointer-events-none">
                                            <i className={charConfig.icon}></i>
                                        </div>

                                        <div className="flex items-center gap-2 mb-1.5 relative z-10">
                                            <i className={`${charConfig.icon} ${charConfig.color} text-sm`}></i>
                                            <span className={`text-xs font-bold uppercase tracking-wider ${charConfig.color}`}>
                                                {charConfig.label}
                                            </span>
                                        </div>
                                        <p className="text-gray-100 text-sm italic relative z-10 leading-relaxed">
                                            "{wish.aiResponse}"
                                        </p>
                                    </div>
                                  ) : (
                                     <div className="bg-dark/20 p-4 rounded-md border-l-2 border-gray-800 mb-4 flex items-center gap-3">
                                        <i className={`fas fa-circle-notch fa-spin ${charConfig.color}`}></i>
                                        <span className="text-gray-500 text-xs italic">Generating response from {charConfig.label}...</span>
                                     </div>
                                  )}

                                  {wish.adminReply && !isReplying && (
                                     <div className="bg-gradient-to-r from-gray-900 to-black p-4 rounded-md border border-gray-700 border-l-[4px] border-l-spidey-red shadow-inner mt-4">
                                        <div className="flex items-center gap-2 mb-2">
                                            <span className="text-xs font-bold uppercase tracking-wider bg-gradient-to-r from-spidey-red to-ghost-flame bg-clip-text text-transparent">
                                              <i className="fas fa-user-shield text-spidey-red mr-1"></i> Official Reply
                                            </span>
                                        </div>
                                        <p className="text-light text-sm">"{wish.adminReply}"</p>
                                     </div>
                                  )}

                                  {isReplying && (
                                      <div className="mt-4 animate-fade-in-up" onClick={(e) => e.stopPropagation()}>
                                          <textarea
                                            value={replyContent}
                                            onChange={(e) => setReplyContent(e.target.value)}
                                            className="w-full bg-black border border-gray-600 rounded p-3 text-sm text-light focus:border-spidey-blue focus:outline-none mb-2"
                                            placeholder="Write an official reply..."
                                            rows={3}
                                            autoFocus
                                          ></textarea>
                                          <div className="flex gap-2 justify-end">
                                              <button 
                                                onClick={(e) => handleCancelReply(e)}
                                                className="text-xs text-gray-400 hover:text-white px-3 py-1 rounded"
                                              >
                                                Cancel
                                              </button>
                                              <button 
                                                onClick={(e) => handleReplySubmit(wish.id, e)}
                                                disabled={isSubmittingReply}
                                                className="text-xs bg-spidey-blue hover:bg-blue-600 text-white px-4 py-1 rounded font-bold uppercase tracking-wider disabled:opacity-50"
                                              >
                                                {isSubmittingReply ? 'Saving...' : 'Post Reply'}
                                              </button>
                                          </div>
                                      </div>
                                  )}
                             </div>
                          </div>

                          {!isOpen && (
                            <div className="flex items-center gap-1 text-gray-600 text-xs mt-1 opacity-60">
                                <span className="uppercase tracking-widest text-[10px] font-bold">Read More</span>
                                <i className="fas fa-chevron-down animate-bounce"></i>
                            </div>
                          )}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>

        {/* Admin Dashboard (Statistics) */}
        {isAdmin && (
           <AdminDashboard 
             wishes={wishes} 
             visitorCount={visitorCount} 
             cloudMode={cloudMode}
             setCloudMode={setCloudMode}
           />
        )}

      </div>

      {themeAnim && (
        <div className="fixed inset-0 flex items-center justify-center z-[100] pointer-events-none">
           <div className="animate-character-pop flex flex-col items-center justify-center">
              <div className={`w-40 h-40 rounded-full border-[8px] bg-dark shadow-[0_0_60px_currentColor] flex items-center justify-center mb-6 ${getHeroConfig(themeAnim).border} ${getHeroConfig(themeAnim).color}`}>
                 <i className={`${getHeroConfig(themeAnim).icon} text-7xl`}></i>
              </div>
              <h2 className={`text-4xl md:text-5xl font-bold uppercase text-white drop-shadow-lg tracking-widest text-center`}>
                  <span className={getHeroConfig(themeAnim).color}>{getHeroConfig(themeAnim).label}</span>
                  <br />
                  <span className="text-2xl text-white/80">Theme Activated</span>
              </h2>
           </div>
        </div>
      )}

      {showLoginModal && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="bg-ghost-black border-[3px] border-spidey-red p-6 rounded-lg shadow-hero max-w-sm w-full relative animate-fade-in-up">
            <button 
              onClick={() => {
                setShowLoginModal(false);
                setAdminPasswordInput('');
              }}
              className="absolute top-2 right-3 text-gray-400 hover:text-white"
            >
              <i className="fas fa-times"></i>
            </button>
            <h4 className="text-xl font-bold text-spidey-red mb-4 uppercase text-center">Admin Access</h4>
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-gray-400 text-xs uppercase font-bold mb-2">Enter Secret Key</label>
                <input 
                  type="password" 
                  inputMode="numeric" 
                  pattern="[0-9]*"
                  value={adminPasswordInput}
                  onChange={(e) => setAdminPasswordInput(e.target.value)}
                  className="w-full bg-dark text-light border-2 border-gray-700 p-3 rounded focus:border-spidey-red focus:outline-none text-center text-lg tracking-widest"
                  placeholder="• • •"
                  autoFocus
                />
              </div>
              <button 
                type="submit" 
                className="w-full bg-spidey-red text-white font-bold py-3 rounded uppercase tracking-wider hover:bg-red-700 transition-colors shadow-lg"
              >
                Unlock
              </button>
            </form>
          </div>
        </div>
      )}
      
      {editModal.show && (
          <div className="fixed inset-0 bg-black/90 z-[70] flex items-end sm:items-center justify-center p-0 sm:p-4 animate-[fadeIn_0.1s_ease-out]">
             <div className="bg-ghost-black border-[3px] border-gray-700 w-full sm:max-w-2xl sm:rounded-lg max-h-[80vh] flex flex-col shadow-[0_0_30px_rgba(0,0,0,0.8)] animate-[slideUp_0.2s_ease-out]">
                <div className="p-4 border-b border-gray-800 flex justify-between items-center sticky top-0 bg-ghost-black z-10">
                    <h4 className="text-xl font-bold text-light uppercase">
                        Select New {editModal.type === 'hero' ? 'Hero' : 'Theme'}
                    </h4>
                    <button 
                        onClick={() => setEditModal({ ...editModal, show: false })}
                        className="text-gray-400 hover:text-white p-2"
                    >
                        <i className="fas fa-times text-xl"></i>
                    </button>
                </div>
                <div className="p-4 overflow-y-auto custom-scrollbar">
                    <div className="grid grid-cols-3 sm:grid-cols-4 gap-3">
                        {heroOptions.map((hero) => (
                             <button
                                key={hero.id}
                                onClick={() => handleEditSelect(hero.id)}
                                className="relative rounded-md border-[2px] border-gray-700 bg-dark hover:border-spidey-blue hover:bg-white/5 transition-all flex flex-col items-center justify-center gap-2 p-3 min-h-[100px]"
                             >
                                <i className={`${hero.icon} text-2xl ${hero.color}`}></i>
                                <span className={`font-bold text-xs text-center leading-tight text-gray-400`}>{hero.label}</span>
                             </button>
                        ))}
                    </div>
                </div>
             </div>
          </div>
      )}

      {contentEditModal.show && (
        <div className="fixed inset-0 bg-black/90 z-[70] flex items-center justify-center p-4 animate-[fadeIn_0.1s_ease-out]">
          <div className="bg-ghost-black border-[3px] border-yellow-500 w-full max-w-lg rounded-lg shadow-[0_0_30px_rgba(234,179,8,0.3)] animate-[zoomIn_0.1s_ease-out]">
             <div className="p-4 border-b border-gray-800 flex justify-between items-center bg-ghost-black rounded-t-lg">
                <h4 className="text-xl font-bold text-yellow-500 uppercase flex items-center gap-2">
                    <i className="fas fa-edit"></i> Edit Wish
                </h4>
                <button 
                    onClick={() => setContentEditModal({ ...contentEditModal, show: false })}
                    className="text-gray-400 hover:text-white p-2"
                >
                    <i className="fas fa-times text-xl"></i>
                </button>
            </div>
            <form onSubmit={handleContentEditSubmit} className="p-6 space-y-4">
               <div>
                  <label className="block text-gray-400 text-xs uppercase font-bold mb-2">Name</label>
                  <input 
                    type="text"
                    value={contentEditModal.name}
                    onChange={(e) => setContentEditModal({ ...contentEditModal, name: e.target.value })}
                    className="w-full bg-dark text-light border border-gray-700 p-3 rounded focus:border-yellow-500 focus:outline-none"
                    required
                  />
               </div>
               <div>
                  <label className="block text-gray-400 text-xs uppercase font-bold mb-2">Email (Optional)</label>
                  <input 
                    type="email"
                    value={contentEditModal.email}
                    onChange={(e) => setContentEditModal({ ...contentEditModal, email: e.target.value })}
                    className="w-full bg-dark text-light border border-gray-700 p-3 rounded focus:border-yellow-500 focus:outline-none"
                  />
               </div>
               <div>
                  <label className="block text-gray-400 text-xs uppercase font-bold mb-2">Message</label>
                  <textarea 
                    value={contentEditModal.message}
                    onChange={(e) => setContentEditModal({ ...contentEditModal, message: e.target.value })}
                    className="w-full bg-dark text-light border border-gray-700 p-3 rounded h-32 focus:border-yellow-500 focus:outline-none"
                    required
                  ></textarea>
               </div>
               <button 
                 type="submit"
                 className="w-full bg-yellow-500 text-black font-bold py-3 rounded uppercase tracking-wider hover:bg-yellow-400 transition-colors shadow-lg mt-2"
               >
                 Save Changes
               </button>
            </form>
          </div>
        </div>
      )}

      {confirmModal.show && (
          <div className="fixed inset-0 bg-black/80 z-[80] flex items-center justify-center p-4 animate-[fadeIn_0.1s_ease-out]">
            <div className={`bg-ghost-black border-[3px] p-6 rounded-lg shadow-[0_0_20px_rgba(220,38,38,0.4)] max-w-sm w-full relative animate-[zoomIn_0.1s_ease-out] ${getModalBorderClass()}`}>
                <h4 className={`text-xl font-bold mb-2 uppercase flex items-center gap-2 ${getModalColorClass()}`}>
                    <i className={`fas ${getModalIcon()}`}></i> 
                    {confirmModal.type === 'logout' ? 'Logout' : confirmModal.type === 'edit' ? 'Confirm Edit' : 'Confirmation'}
                </h4>
                <p className="text-gray-300 mb-4">
                    {getConfirmationText()}
                </p>
                
                <div className="flex gap-3">
                    <button 
                        onClick={() => setConfirmModal({ ...confirmModal, show: false })}
                        className="flex-1 py-3 bg-gray-800 hover:bg-gray-700 text-white font-bold rounded uppercase tracking-wider transition-colors"
                    >
                        Cancel
                    </button>
                    <button 
                        onClick={executeAction}
                        className={`flex-1 py-3 text-white font-bold rounded uppercase tracking-wider transition-colors shadow-lg ${getModalButtonBg()}`}
                    >
                        {confirmModal.type === 'logout' ? 'Logout' : 'Confirm'}
                    </button>
                </div>
            </div>
          </div>
      )}

      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          width: 8px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: #131313; 
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background: #333; 
          border-radius: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #555; 
        }
        
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes slideUp {
            from { transform: translateY(100%); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes characterPop {
          0% { transform: scale(0.5) translateY(20px); opacity: 0; filter: blur(10px); }
          40% { transform: scale(1.1) translateY(0); opacity: 1; filter: blur(0); }
          50% { transform: scale(1); }
          80% { transform: scale(1); opacity: 1; }
          100% { transform: scale(1.2); opacity: 0; filter: blur(10px); }
        }
        
        .animate-fade-in-up {
          animation: fadeInUp 0.4s ease-out forwards;
        }
        
        .animate-character-pop {
          animation: characterPop 1.2s cubic-bezier(0.34, 1.56, 0.64, 1) forwards;
        }
      `}</style>
    </section>
  );
};

export default WishSection;
