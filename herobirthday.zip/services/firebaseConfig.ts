
import firebase from "firebase/compat/app";
import "firebase/compat/firestore";
import "firebase/compat/storage";
import "firebase/compat/analytics";

const env = (import.meta as any).env || {};

export let db: firebase.firestore.Firestore | null = null;
export let storage: firebase.storage.Storage | null = null;
export let analytics: firebase.analytics.Analytics | null = null;
export let app: firebase.app.App | undefined;

// Function to save user-provided config and reload
export const saveFirebaseConfig = (config: any) => {
  try {
    // Basic validation before saving
    if (!config.apiKey || !config.projectId) {
      alert("Invalid Configuration: API Key and Project ID are required.");
      return;
    }
    localStorage.setItem('hero_firebase_config', JSON.stringify(config));
    window.location.reload();
  } catch (error) {
    console.error("Failed to save config to local storage", error);
    alert("Failed to save configuration. Please check your browser settings.");
  }
};

// Function to get current custom config
export const getFirebaseConfig = () => {
  const saved = localStorage.getItem('hero_firebase_config');
  if (saved) return JSON.parse(saved);
  
  // Return the default hardcoded config if no local override
  return {
    apiKey: "AIzaSyBGF9rMw-avFvNufSu51Nyr-ALk05k7Qcw",
    authDomain: "manav-b74ae.firebaseapp.com",
    projectId: "manav-b74ae",
    storageBucket: "manav-b74ae.firebasestorage.app",
    messagingSenderId: "405788459632",
    appId: "1:405788459632:web:40a284b8881aca4a282ab5",
    measurementId: "G-G3GCWD4TGV"
  };
};

// Function to reset config
export const clearFirebaseConfig = () => {
  localStorage.removeItem('hero_firebase_config');
  window.location.reload();
};

const initialize = () => {
  try {
    let config = null;
    const savedConfig = localStorage.getItem('hero_firebase_config');
    
    if (savedConfig) {
      try {
        config = JSON.parse(savedConfig);
      } catch(e) {
        console.error("Error parsing saved config", e);
      }
    }
    
    // If no custom local config, use the provided default credentials
    if (!config) {
       config = {
        apiKey: "AIzaSyBGF9rMw-avFvNufSu51Nyr-ALk05k7Qcw",
        authDomain: "manav-b74ae.firebaseapp.com",
        projectId: "manav-b74ae",
        storageBucket: "manav-b74ae.firebasestorage.app",
        messagingSenderId: "405788459632",
        appId: "1:405788459632:web:40a284b8881aca4a282ab5",
        measurementId: "G-G3GCWD4TGV"
      };
    }

    // CRITICAL SAFETY CHECK: Only initialize if we have a valid config
    if (config && config.apiKey && config.projectId && config.apiKey.trim() !== '') {
      try {
        if (!firebase.apps.length) {
          app = firebase.initializeApp(config);
        } else {
          app = firebase.app();
        }
          
        // Use standard Firestore initialization
        try {
          db = firebase.firestore();
        } catch (firestoreError) {
          console.warn("Firestore initialization failed:", firestoreError);
        }
        
        // Initialize Storage
        try {
          storage = firebase.storage();
        } catch (storageError) {
            console.warn("Storage initialization failed:", storageError);
        }

        // Initialize Analytics if Measurement ID is present
        if (config.measurementId) {
          try {
            analytics = firebase.analytics();
            console.log("Firebase Analytics initialized");
          } catch (analyticsError) {
            console.warn("Analytics initialization failed (possibly blocked):", analyticsError);
          }
        }
        
        console.log("Firebase initialized successfully");
      } catch (err) {
        console.error("Firebase init failed", err);
        if (savedConfig) {
          console.warn("Detected bad config causing crash. Resetting...");
        }
      }
    } else {
      console.log("No valid Firebase config found. App running in local-only mode.");
    }
  } catch (fatalError) {
    console.error("Fatal error during Firebase initialization:", fatalError);
  }
};

initialize();
