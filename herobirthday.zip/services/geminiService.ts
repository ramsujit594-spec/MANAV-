
import { GoogleGenAI } from "@google/genai";
import { HeroCharacter } from "../types";

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const getInstantHeroResponse = (hero: HeroCharacter, userName: string = ""): string => {
  const name = userName || "Friend";
  
  switch (hero) {
    case 'spiderman':
      return `Thwip! Thanks ${name}! Your wish is amazing. My Spidey-senses are tingling for Manav's big birthday bash! 🕷️🕸️`;
    case 'ghost':
      return `Your voice echoes in the void, ${name}. I have received your wish for Manav. The flame burns bright! 🔥💀`;
    case 'ironman':
      return `Jarvis recorded that, ${name}. Solid wish! Sending Manav some Stark-level upgrades for his birthday. Let's party! 🚀🦾`;
    case 'captainamerica':
      return `That's a wish worth fighting for, ${name}. I salute your spirit! Happy Birthday to Manav from the Avengers! 🛡️🇺🇸`;
    case 'deadpool':
      return `Whoa ${name}, nice typing! I'm here for the chimichangas and Manav's birthday. Maximum effort on this party! 🌮⚔️`;
    case 'hulk':
      return `HULK LIKE WISH FROM ${name.toUpperCase()}! HULK SMASH CAKE FOR MANAV! TINY MANAV HAVE GOOD BIRTHDAY! 💚👊`;
    case 'thor':
      return `By Odin's beard, ${name}! Your words thunder with kindness. Manav shall have a feast worthy of Valhalla! ⚡🔨`;
    case 'doctorstrange':
      return `By the Hoary Hosts of Hoggoth, ${name}! Your wish weaves a fine spell for Manav's future. 🔮✨`;
    case 'batman':
      return `I've analyzed your wish, ${name}. It's adequate. Gotham sends its regards to Manav. Now I vanish. 🦇🌑`;
    case 'wolverine':
      return `Alright ${name}, that's a decent wish. Hope Manav survives the party. I'm grabbing a drink. Snikt! 🐺⚔️`;
    case 'blackpanther':
      return `Wakanda Forever, ${name}! Your wish honors us. King T'Challa wishes Manav strength and glory today! 🙅🏾‍♂️🐆`;
    case 'wonderwoman':
      return `Great Hera, ${name}! Your heart is pure. I bestow Amazonian blessings upon Manav for a wonderful year! 💫👑`;
    case 'flash':
      return `Whoosh! Got your message in a microsecond, ${name}! Racing over to wish Manav the fastest birthday ever! ⚡🏃`;
    case 'aquaman':
      return `The seven seas roar for ${name}! Atlantis celebrates Manav today. May the tides bring him fortune! 🔱🌊`;
    case 'groot':
      return `I AM GROOT! (Translation: That was a sweet wish, ${name}! Happy Birthday Manav!) 🌳🌱`;
    default:
      return `Message received, ${name}! Your wish has been logged at HQ. Happy Birthday Manav! ✨`;
  }
};

export const generateHeroResponse = async (
  userName: string, 
  userMessage: string, 
  hero: HeroCharacter
): Promise<string> => {
  const ai = getClient();
  if (!ai) {
    return getInstantHeroResponse(hero, userName);
  }

  // System instructions: Persona + Max 25 Words + Emoji + Reply to User
  let systemInstruction = "";

  switch (hero) {
    case 'spiderman':
      systemInstruction = "You are Spider-Man. Reply to the user. Be friendly, crack a joke, and wish Manav a great birthday. Max 25 words. Use spider emojis.";
      break;
    case 'ghost':
      systemInstruction = "You are Ghost. Reply to the user. Be mysterious and intense. Wish Manav a powerful birthday. Max 25 words. Use fire emojis.";
      break;
    case 'ironman':
      systemInstruction = "You are Iron Man (Tony Stark). Reply to the user. Be confident and tech-savvy. Wish Manav a grand birthday. Max 25 words. Use tech emojis.";
      break;
    case 'captainamerica':
      systemInstruction = "You are Captain America. Reply to the user. Be patriotic and encouraging. Wish Manav a heroic birthday. Max 25 words. Use shield emojis.";
      break;
    case 'deadpool':
      systemInstruction = "You are Deadpool. Reply to the user. Break the fourth wall. Be funny. Wish Manav a crazy birthday. Max 25 words. Use taco emojis.";
      break;
    case 'hulk':
      systemInstruction = "You are Hulk. Reply to the user. Speak in third person (HULK SMASH). Be loud. Wish Manav birthday. Max 25 words. Use fist emojis.";
      break;
    case 'thor':
      systemInstruction = "You are Thor. Reply to the user. Speak Shakespearean. Be mighty. Wish Manav a thunderous birthday. Max 25 words. Use hammer emojis.";
      break;
    case 'doctorstrange':
      systemInstruction = "You are Dr. Strange. Reply to the user. Mention timelines or magic. Wish Manav a magical birthday. Max 25 words. Use magic emojis.";
      break;
    case 'batman':
      systemInstruction = "You are Batman. Reply to the user. Be dark, brooding, but sincere. Wish Manav a birthday. Max 25 words. Use bat emojis.";
      break;
    case 'wolverine':
      systemInstruction = "You are Wolverine. Reply to the user. Call them 'Bub'. Be gruff. Wish Manav a birthday. Max 25 words. Use claw emojis.";
      break;
    case 'blackpanther':
      systemInstruction = "You are Black Panther. Reply to the user. Be regal and noble. Wish Manav glory. Max 25 words. Use Wakanda emojis.";
      break;
    case 'wonderwoman':
      systemInstruction = "You are Wonder Woman. Reply to the user. Be compassionate and strong. Wish Manav love. Max 25 words. Use star emojis.";
      break;
    case 'flash':
      systemInstruction = "You are The Flash. Reply to the user. Speak fast/energetic. Wish Manav a quick birthday. Max 25 words. Use lightning emojis.";
      break;
    case 'aquaman':
      systemInstruction = "You are Aquaman. Reply to the user. Mention the ocean. Wish Manav deep joy. Max 25 words. Use water emojis.";
      break;
    case 'groot':
      systemInstruction = "You are Groot. Start with 'I am Groot'. Add translation in parentheses wishing Manav HBD. Max 25 words. Use tree emojis.";
      break;
    default:
      systemInstruction = "You are a superhero. Reply to the user. Wish Manav Happy Birthday. Max 25 words. Use emojis.";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      // Prompt injects user name and message for context
      contents: `User ${userName} said: "${userMessage}". As ${hero}, reply directly to ${userName}. React to their message and wish Manav happy birthday. Max 25 words. Include emojis.`,
      config: {
        systemInstruction: systemInstruction,
        temperature: 0.8, // Good balance for 25 words
        topK: 1, // Greedy decoding for 0.1s speed feel
        maxOutputTokens: 50, // Enough for 25 words
        thinkingConfig: { thinkingBudget: 0 },
      }
    });

    return response.text || getInstantHeroResponse(hero, userName);
  } catch (error) {
    console.error("Error generating hero response:", error);
    return getInstantHeroResponse(hero, userName);
  }
};

export const generateAiWish = async (hero: HeroCharacter): Promise<string> => {
  const ai = getClient();
  if (!ai) {
    return "Happy Birthday Manav! Hope you have an epic day full of adventure! 🎂✨";
  }

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: `Write a short, creative birthday wish for Manav (the birthday boy). The wish should be themed around ${hero} (e.g. referencing their powers, catchphrases, or style). Max 15 words. Include relevant emojis.`,
      config: {
        temperature: 0.9, // High creativity
        topK: 40,
        maxOutputTokens: 40,
        thinkingConfig: { thinkingBudget: 0 },
      }
    });

    return response.text || "Happy Birthday Manav! Have a blast! 🎉";
  } catch (error) {
    console.error("Error generating AI wish:", error);
    return "Happy Birthday Manav! Hope it's legendary! 🥳";
  }
};
