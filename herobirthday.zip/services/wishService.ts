
import { Wish, HeroCharacter } from '../types';
import { generateHeroResponse, getInstantHeroResponse } from './geminiService';
import { db, storage } from './firebaseConfig';
import firebase from 'firebase/compat/app';
import 'firebase/compat/firestore';
import 'firebase/compat/storage';

const STORAGE_KEY = 'hero_birthday_wishes';
const COLLECTION_NAME = 'wishes';
const STATS_DOC_ID = 'visitors';
const STATS_COLLECTION = 'stats';

// --- Connection Status Helper ---
export const isCloudSyncActive = (): boolean => {
  return !!db;
};

export const isCloudStorageActive = (): boolean => {
  return !!storage;
};

// --- Local Storage Helpers (Fallback) ---

const getLocalWishes = (): Wish[] => {
  const stored = localStorage.getItem(STORAGE_KEY);
  if (!stored) return [];
  try {
    return JSON.parse(stored).sort((a: Wish, b: Wish) => b.timestamp - a.timestamp);
  } catch (e) {
    return [];
  }
};

const saveLocalWishes = (wishes: Wish[]) => {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(wishes));
  // Dispatch event for local reactive updates
  window.dispatchEvent(new Event('local-wish-update'));
};

// --- Sync & Backup Functionality ---

export const migrateLocalToCloud = async (): Promise<number> => {
  if (!db) return 0;
  
  const localWishes = getLocalWishes();
  if (localWishes.length === 0) return 0;

  // Batch writes (max 500 per batch)
  const chunkArray = <T>(arr: T[], size: number): T[][] => {
    const res: T[][] = [];
    for (let i = 0; i < arr.length; i += size) {
        res.push(arr.slice(i, i + size));
    }
    return res;
  }

  const chunks = chunkArray(localWishes, 450); // Safe margin below 500
  let totalCount = 0;

  try {
    for (const chunk of chunks) {
        const batch = db.batch();
        chunk.forEach(wish => {
            // Ensure ID is string. Use set with merge to avoid overwriting newer cloud data fields if they exist
            const docRef = db!.collection(COLLECTION_NAME).doc(String(wish.id));
            batch.set(docRef, wish, { merge: true });
        });
        await batch.commit();
        totalCount += chunk.length;
    }
    console.log(`Successfully synced ${totalCount} wishes to cloud.`);
  } catch (error) {
    console.error("Migration failed (likely permissions):", error);
    // Don't throw, just log, so app doesn't crash during toggle
  }
  
  return totalCount;
};

export const uploadBackupToCloud = async (blob: Blob, filename: string): Promise<string> => {
    if (!storage) throw new Error("Cloud storage is not configured.");
    
    try {
        const storageRef = storage.ref(`backups/${filename}`);
        await storageRef.put(blob);
        const downloadURL = await storageRef.getDownloadURL();
        return downloadURL;
    } catch (error) {
        console.error("Backup upload failed:", error);
        throw error;
    }
};

// --- Main Service Functions ---

// Subscribe to real-time updates
export const subscribeToWishes = (onUpdate: (wishes: Wish[]) => void, enableCloud: boolean = true): () => void => {
  // Only use DB if it exists AND cloud is enabled
  if (db && enableCloud) {
    const q = db.collection(COLLECTION_NAME).orderBy('timestamp', 'desc');
    
    // onSnapshot sets up a continuous listener
    const unsubscribe = q.onSnapshot({ includeMetadataChanges: true }, (snapshot) => {
      const wishes = snapshot.docs.map(d => ({ id: d.id, ...d.data() } as Wish));
      onUpdate(wishes);
    }, (error) => {
      console.warn("Firebase sync error (falling back to local):", error.message);
      // Fallback to local if subscription fails (e.g. permissions)
      const handleFallback = () => onUpdate(getLocalWishes());
      window.addEventListener('local-wish-update', handleFallback);
      handleFallback();
    });
    
    return () => {
        unsubscribe();
        window.removeEventListener('local-wish-update', () => {}); // Cleanup fallback listener if strictly needed, though anon func makes it hard.
        // In practice, a full cleanup would require named function, but for this fallback scope it's acceptable.
    };
  }

  // Fallback / Offline Mode Logic
  const handleLocalUpdate = () => onUpdate(getLocalWishes());
  window.addEventListener('local-wish-update', handleLocalUpdate);
  
  // Initial load
  onUpdate(getLocalWishes());
  
  return () => {
    window.removeEventListener('local-wish-update', handleLocalUpdate);
  };
};

export const getWishes = async (enableCloud: boolean = true): Promise<Wish[]> => {
  if (db && enableCloud) {
    try {
      const querySnapshot = await db.collection(COLLECTION_NAME).orderBy('timestamp', 'desc').get();
      return querySnapshot.docs.map(d => ({ id: d.id, ...d.data() } as Wish));
    } catch (error) {
      console.warn("Error fetching from Firebase, falling back to local:", error);
      return getLocalWishes();
    }
  }
  
  return getLocalWishes();
};

export const createWish = async (
  name: string, 
  message: string, 
  character: HeroCharacter, 
  theme: HeroCharacter, 
  email?: string,
  enableCloud: boolean = true
): Promise<Wish> => {
  const timestamp = Date.now();
  
  // 0.05s Instant Feedback
  const instantResponse = getInstantHeroResponse(character, name);

  const baseWishData = {
    name,
    email,
    message,
    timestamp,
    character,
    theme,
    aiResponse: instantResponse
  };

  if (db && enableCloud) {
    try {
      // Create a reference first to get the ID synchronously
      const newDocRef = db.collection(COLLECTION_NAME).doc();
      const newWish = { id: newDocRef.id, ...baseWishData } as Wish;
      
      // Save immediately (Firestore SDK handles optimistic update)
      // We attach a catch here: if Cloud fails (Permissions), we save to local immediately
      newDocRef.set(baseWishData).catch((err) => {
          console.warn("Cloud write failed (permissions?), saving locally backup:", err.message);
          const currentWishes = getLocalWishes();
          saveLocalWishes([newWish, ...currentWishes]);
      });
      
      // Background Process: Generate Real AI Response
      generateHeroResponse(name, message, character).then(async (aiText) => {
        try {
          // Try to update cloud
          await newDocRef.update({ aiResponse: aiText });
        } catch (err) {
            // If cloud failed, update local
            console.warn("Cloud AI update failed, updating local", err);
            const current = getLocalWishes();
            const updated = current.map(w => w.id === newWish.id ? { ...w, aiResponse: aiText } : w);
            saveLocalWishes(updated);
        }
      });
      
      return newWish;
    } catch (error) {
      console.error("Error initiating Firebase save, saving locally instead:", error);
    }
  }

  // Local Storage Logic
  const localId = (Date.now() + Math.random()).toString().replace('.', '');
  const newWish: Wish = {
    id: localId,
    ...baseWishData
  };
  
  const currentWishes = getLocalWishes();
  saveLocalWishes([newWish, ...currentWishes]);

  // Background Process for Local Storage
  generateHeroResponse(name, message, character).then((aiText) => {
     const wishes = getLocalWishes();
     const updated = wishes.map(w => {
       if (w.id === localId) {
         return { ...w, aiResponse: aiText };
       }
       return w;
     });
     saveLocalWishes(updated);
  });

  return newWish;
};

export const updateWishReply = async (id: string, reply: string, enableCloud: boolean = true): Promise<void> => {
  // Optimistically update local always for UI responsiveness
  const currentWishes = getLocalWishes();
  const updatedWishes = currentWishes.map(w => {
    if (String(w.id) === String(id)) {
      return { ...w, adminReply: reply };
    }
    return w;
  });
  saveLocalWishes(updatedWishes);

  if (db && enableCloud) {
    try {
      const wishRef = db.collection(COLLECTION_NAME).doc(id);
      await wishRef.update({ adminReply: reply });
      return;
    } catch (error) {
      console.warn("Error updating reply in Firebase (kept local):", error);
    }
  }
};

export const updateWishCharacter = async (id: string, character: HeroCharacter, enableCloud: boolean = true): Promise<void> => {
  // Optimistic Local
  const currentWishes = getLocalWishes();
  const updatedWishes = currentWishes.map(w => {
    if (String(w.id) === String(id)) {
      return { ...w, character };
    }
    return w;
  });
  saveLocalWishes(updatedWishes);

  if (db && enableCloud) {
    try {
      const wishRef = db.collection(COLLECTION_NAME).doc(id);
      await wishRef.update({ character });
      return;
    } catch (error) {
      console.warn("Error updating character in Firebase (kept local):", error);
    }
  }
};

export const updateWishTheme = async (id: string, theme: HeroCharacter, enableCloud: boolean = true): Promise<void> => {
  // Optimistic Local
  const currentWishes = getLocalWishes();
  const updatedWishes = currentWishes.map(w => {
    if (String(w.id) === String(id)) {
      return { ...w, theme };
    }
    return w;
  });
  saveLocalWishes(updatedWishes);

  if (db && enableCloud) {
    try {
      const wishRef = db.collection(COLLECTION_NAME).doc(id);
      await wishRef.update({ theme });
      return;
    } catch (error) {
      console.warn("Error updating theme in Firebase (kept local):", error);
    }
  }
};

export const updateWishDetails = async (id: string, updates: { name?: string, email?: string, message?: string }, enableCloud: boolean = true): Promise<void> => {
  // Optimistic Local
  const currentWishes = getLocalWishes();
  const updatedWishes = currentWishes.map(w => {
    if (String(w.id) === String(id)) {
      return { ...w, ...updates };
    }
    return w;
  });
  saveLocalWishes(updatedWishes);

  if (db && enableCloud) {
    try {
      const wishRef = db.collection(COLLECTION_NAME).doc(id);
      await wishRef.update(updates);
      return;
    } catch (error) {
      console.warn("Error updating details in Firebase (kept local):", error);
    }
  }
};

export const deleteWish = async (id: string, enableCloud: boolean = true): Promise<void> => {
  const targetId = String(id);

  // Optimistic Local Delete
  const currentWishes = getLocalWishes();
  const updatedWishes = currentWishes.filter(w => String(w.id) !== targetId);
  if (updatedWishes.length === 0) {
      localStorage.removeItem(STORAGE_KEY);
      window.dispatchEvent(new Event('local-wish-update')); 
  } else {
      saveLocalWishes(updatedWishes);
  }

  if (db && enableCloud) {
    db.collection(COLLECTION_NAME).doc(targetId).delete().catch(err => 
        console.warn("Firebase delete error (handled locally):", err)
    );
    return;
  }
};

export const clearAllWishes = async (enableCloud: boolean = true): Promise<void> => {
  // Clear Local
  localStorage.removeItem(STORAGE_KEY);
  window.dispatchEvent(new Event('local-wish-update'));

  if (db && enableCloud) {
      db.collection(COLLECTION_NAME).get().then(async (snapshot) => {
        const batch = db!.batch();
        snapshot.docs.forEach((doc) => {
            batch.delete(doc.ref);
        });
        await batch.commit();
      }).catch(err => console.warn("Firebase clear error (handled locally):", err));
      return;
  }
};

// --- Statistics & Visitor Tracking ---

export const trackVisit = async (enableCloud: boolean = true): Promise<void> => {
  if (sessionStorage.getItem('hero_session_visited')) {
    return;
  }
  sessionStorage.setItem('hero_session_visited', 'true');

  const incrementLocal = () => {
      const currentCount = parseInt(localStorage.getItem('hero_visitor_count') || '0');
      localStorage.setItem('hero_visitor_count', (currentCount + 1).toString());
      window.dispatchEvent(new Event('local-stats-update'));
  };

  if (db && enableCloud) {
    try {
      const statsRef = db.collection(STATS_COLLECTION).doc(STATS_DOC_ID);
      const docSnap = await statsRef.get().catch(() => null); // Catch read permission error
      
      if (docSnap && docSnap.exists) {
        await statsRef.update({ count: firebase.firestore.FieldValue.increment(1) });
      } else {
        // If read fails or doesn't exist, try set. If that fails, it goes to catch.
        await statsRef.set({ count: 1 }, { merge: true });
      }
    } catch (error) {
      console.warn("Error tracking visit in Firebase, falling back to local:", error);
      incrementLocal();
    }
  } else {
    incrementLocal();
  }
};

export const subscribeToVisitorCount = (onUpdate: (count: number) => void, enableCloud: boolean = true): () => void => {
  const handleLocalStats = () => {
    const count = parseInt(localStorage.getItem('hero_visitor_count') || '0');
    onUpdate(count);
  };

  if (db && enableCloud) {
    const statsRef = db.collection(STATS_COLLECTION).doc(STATS_DOC_ID);
    
    // Attempt to listen to cloud
    const unsubscribe = statsRef.onSnapshot((doc) => {
      if (doc.exists) {
        onUpdate(doc.data()?.count || 0);
      } else {
        // Doc might not exist yet, fallback to local count if 0
        const local = parseInt(localStorage.getItem('hero_visitor_count') || '0');
        onUpdate(Math.max(0, local));
      }
    }, (error) => {
      console.warn("Visitor sync error (permissions?), falling back to local:", error.message);
      // Fallback: Use local listener
      window.addEventListener('local-stats-update', handleLocalStats);
      handleLocalStats();
    });
    
    // Cleanup: Unsubscribe from cloud AND local
    return () => {
        unsubscribe();
        window.removeEventListener('local-stats-update', handleLocalStats);
    };
  }

  // Local only mode
  window.addEventListener('local-stats-update', handleLocalStats);
  handleLocalStats(); 
  
  return () => {
    window.removeEventListener('local-stats-update', handleLocalStats);
  };
};
